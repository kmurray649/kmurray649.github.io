import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

// input is a data map supplied by the Python host, not executable text.
def required = ['case_number', 'recipient', 'date', 'time', 'timezone', 'courtroom']
def missing = required.findAll { !input[it]?.toString()?.trim() }
if (missing) {
    throw new IllegalArgumentException('Required: ' + missing.collect { it.replace('_', ' ') }.join(', '))
}
def day
def clock
try {
    if (!(input.date ==~ /\d{4}-\d{2}-\d{2}/) || !(input.time ==~ /\d{2}:\d{2}/)) {
        throw new IllegalArgumentException('Invalid format')
    }
    day = LocalDate.parse(input.date.toString())
    clock = LocalTime.parse(input.time.toString(), DateTimeFormatter.ofPattern('HH:mm').withResolverStyle(ResolverStyle.STRICT))
} catch (Exception ignored) {
    throw new IllegalArgumentException('Use YYYY-MM-DD for the date and 24-hour HH:MM for the time.')
}
def zone
try {
    zone = ZoneId.of(input.timezone.toString())
} catch (Exception ignored) {
    throw new IllegalArgumentException('Unknown time zone. Use an IANA name such as America/Denver.')
}
def offsets = zone.rules.getValidOffsets(day.atTime(clock))
if (offsets.isEmpty()) {
    throw new IllegalArgumentException('This local time does not exist due to a daylight-saving change.')
}
if (offsets.size() > 1) {
    throw new IllegalArgumentException('This local time is ambiguous due to a daylight-saving change. Choose another time.')
}
return [valid: true, rule: 'hearing.groovy', engine: 'Apache Groovy']
