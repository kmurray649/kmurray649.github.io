// Configurable administrative checklist; staff make filing acceptance decisions.
def issues = []
def queue
if (input.filing_type != 'Civil Complaint') {
    issues << 'Document type requires manual classification.'
    queue = 'Manual Classification'
} else {
    if (!input.submitter?.toString()?.trim()) {
        issues << 'Submitter name is missing.'
    }
    if (!input.has_complaint || !input.readable) {
        issues << 'A readable complaint attachment is missing.'
    }
    queue = issues ? 'Intake Follow-up' : 'Civil Clerk Review'
}
return [queue: queue, issues: issues, rule: 'intake.groovy', engine: 'Apache Groovy']
