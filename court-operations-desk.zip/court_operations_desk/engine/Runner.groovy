import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.lang.Binding
import groovy.lang.GroovyShell
import org.apache.velocity.app.VelocityEngine
import org.apache.velocity.VelocityContext
import org.apache.velocity.runtime.VelocityEngineVersion

if (Runtime.version().feature() < 17) {
    System.err.println('Java 17 or newer is required.')
    System.exit(2)
}
def base = new File(args[0]).canonicalFile
def shell = new GroovyShell(this.class.classLoader)
def scripts = [
    hearing: shell.parse(new File(base, 'rules/hearing.groovy')),
    intake: shell.parse(new File(base, 'rules/intake.groovy'))
]
def velocity = new VelocityEngine()
velocity.setProperty('runtime.strict_mode.enable', true)
velocity.setProperty('introspector.uberspect.class', 'org.apache.velocity.util.introspection.SecureUberspector')
// Only in-memory resources: #parse/#include cannot load arbitrary local files.
velocity.setProperty('resource.loaders', 'string')
velocity.setProperty('resource.loader.string.class', 'org.apache.velocity.runtime.resource.loader.StringResourceLoader')
velocity.setProperty('directive.foreach.max_loops', 1000)
velocity.setProperty('velocimacro.max_depth', 20)
velocity.init()
long ruleCalls = 0
long renderCalls = 0
def reader = new BufferedReader(new InputStreamReader(System.in, 'UTF-8'))
def writer = new PrintWriter(new OutputStreamWriter(System.out, 'UTF-8'), true)
String line
while ((line = reader.readLine()) != null) {
    def request
    try {
        request = new JsonSlurper().parseText(line)
        def result
        switch (request.operation) {
            case 'about':
                result = [groovy: GroovySystem.version, velocity: VelocityEngineVersion.VERSION,
                          java: System.getProperty('java.version'), rules_executed: ruleCalls,
                          templates_rendered: renderCalls, mode: 'Apache engines (JVM)']
                break
            case 'rule':
                def script = scripts[request.rule]
                if (script == null) throw new IllegalArgumentException('Unknown rule')
                script.binding = new Binding([input: request.input, out: new PrintWriter(System.err, true)])
                result = script.run()
                ruleCalls++
                break
            case 'render':
                def context = new VelocityContext()
                request.context.each { key, value -> context.put(key.toString(), value) }
                def output = new StringWriter()
                velocity.evaluate(context, output, 'court-template', request.template.toString())
                renderCalls++
                result = [body: output.toString(), engine: 'Apache Velocity', version: VelocityEngineVersion.VERSION]
                break
            default:
                throw new IllegalArgumentException('Unknown operation')
        }
        writer.println(JsonOutput.toJson([id: request.id, ok: true, result: result]))
    } catch (Throwable error) {
        writer.println(JsonOutput.toJson([id: request?.id, ok: false, error: error.message ?: error.class.simpleName]))
    }
}
