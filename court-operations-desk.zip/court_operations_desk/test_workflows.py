import sqlite3
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from core import Store
from workflow_core import amount_cents, task_overdue
from test_core import hearing

def task(**changes):
    return dict(dict(case_number='DEMO-1',title='Arrange interpreter',owner='Clerk A',
                     due_on='2026-11-12',category='Interpreter request',status='Open',notes='French requested'),**changes)

def service(**changes):
    return dict(dict(case_number='DEMO-1',document_title='Hearing notice',recipient='Alex Morgan',
                     method='Mail',assigned_to='Clerk B',status='Pending',event_on='',notes=''),**changes)

class AdditionalWorkflowTests(unittest.TestCase):
    def setUp(self): self.store=Store(':memory:')
    def tearDown(self): self.store.close()

    def test_task_requires_owner_and_date(self):
        for data in [task(owner=''),task(due_on='2026-02-30')]:
            with self.assertRaises(ValueError): self.store.save_work_item('tasks',data)
        self.assertEqual([],self.store.rows('tasks'))

    def test_overdue_only_for_unfinished_tasks(self):
        day=date(2026,11,13)
        self.assertTrue(task_overdue(task(),day))
        self.assertFalse(task_overdue(task(status='Completed'),day))
        self.assertFalse(task_overdue(task(status='Cancelled'),day))
        self.assertFalse(task_overdue(task(),date(2026,11,12)))

    def test_task_update_and_stale_edit(self):
        i=self.store.save_work_item('tasks',task())
        self.store.save_work_item('tasks',task(status='Completed'),i,1)
        self.assertEqual(2,self.store.get('tasks',i)['revision'])
        with self.assertRaises(ValueError): self.store.save_work_item('tasks',task(owner='Clerk B'),i,1)
        self.assertEqual('Completed',self.store.get('tasks',i)['status'])

    def test_service_report_requires_reporter_and_date(self):
        for values in [service(status='Reported served'),service(status='Reported served',assigned_to='',event_on=date.today().isoformat())]:
            with self.assertRaises(ValueError): self.store.save_work_item('services',values)

    def test_service_attempt_and_reported_outcome(self):
        today=date.today().isoformat()
        i=self.store.save_work_item('services',service())
        self.store.save_work_item('services',service(status='Attempted',event_on=today,notes='No response'),i,1)
        self.store.save_work_item('services',service(status='Returned unserved',event_on=today,notes='Forwarded for follow-up'),i,2)
        self.assertEqual('Returned unserved',self.store.get('services',i)['status'])
        self.assertEqual(3,self.store.get('services',i)['revision'])

    def test_future_reported_service_rejected(self):
        tomorrow=(date.today()+timedelta(days=1)).isoformat()
        with self.assertRaises(ValueError): self.store.save_work_item('services',service(status='Reported served',event_on=tomorrow))

    def test_cent_precision_and_invalid_money(self):
        self.assertEqual(29,amount_cents('0.29'))
        for value in ['NaN','Infinity','-1','0','1.001','abc','1000001']:
            with self.assertRaises(ValueError): amount_cents(value)

    def test_partial_payment_and_waiver(self):
        self.store.post_ledger('DEMO-1','Charge','100.29','Assessment','A')
        self.store.post_ledger('DEMO-1','Payment','20.10','Payment recorded','B')
        self.store.post_ledger('DEMO-1','Waiver','10.00','Waiver recorded','C')
        self.assertEqual(7019,self.store.ledger_balance('DEMO-1'))

    def test_overpayment_rejected_without_writes(self):
        self.store.post_ledger('DEMO-1','Charge','25.00','Assessment','A')
        count=len(self.store.rows('activity'))
        with self.assertRaises(ValueError): self.store.post_ledger('DEMO-1','Payment','30','Payment','B')
        self.assertEqual(1,len(self.store.rows('ledger')))
        self.assertEqual(count,len(self.store.rows('activity')))

    def test_retry_reuses_entry_and_reference_conflict_rejected(self):
        first,created=self.store.post_ledger('DEMO-1','Charge','25.00','Assessment','A')
        second,created=self.store.post_ledger('DEMO-1','Charge','25','Assessment','A')
        self.assertFalse(created); self.assertEqual(first['id'],second['id'])
        with self.assertRaises(ValueError): self.store.post_ledger('DEMO-2','Charge','25','Assessment','A')

    def test_reversal_preserves_original_and_prevents_duplicates(self):
        charge,_=self.store.post_ledger('DEMO-1','Charge','25','Assessment','A')
        reversal=self.store.reverse_ledger(charge['id'],'Entered against wrong case')
        self.assertEqual(0,self.store.ledger_balance('DEMO-1'))
        self.assertEqual(charge['id'],reversal['reversal_of'])
        self.assertEqual('Charge',self.store.get('ledger',charge['id'])['kind'])
        with self.assertRaises(ValueError): self.store.reverse_ledger(charge['id'],'Repeat')
        with self.assertRaises(ValueError): self.store.reverse_ledger(reversal['id'],'Undo reversal')

    def test_reverse_paid_charge_requires_payment_reversal_first(self):
        c,_=self.store.post_ledger('DEMO-1','Charge','50','Assessment','A')
        p,_=self.store.post_ledger('DEMO-1','Payment','20','Payment','B')
        with self.assertRaises(ValueError): self.store.reverse_ledger(c['id'],'Wrong case')
        self.store.reverse_ledger(p['id'],'Payment moved to correct case')
        self.store.reverse_ledger(c['id'],'Assessment moved to correct case')
        self.assertEqual(0,self.store.ledger_balance('DEMO-1'))

    def test_balances_separate_by_case(self):
        self.store.post_ledger('DEMO-1','Charge','25','Assessment','A')
        self.store.post_ledger('DEMO-2','Charge','40','Assessment','B')
        self.assertEqual(2500,self.store.ledger_balance('DEMO-1'))
        self.assertEqual(4000,self.store.ledger_balance('DEMO-2'))

    def test_docket_date_room_and_same_start_warning(self):
        self.store.save_hearing(hearing())
        self.store.save_hearing(hearing(case_number='DEMO-2'))
        self.store.save_hearing(hearing(case_number='DEMO-3',courtroom='102'))
        self.store.save_hearing(hearing(case_number='DEMO-4',date='2026-11-13'))
        rows=self.store.docket('2026-11-12')
        self.assertEqual(3,len(rows)); self.assertEqual(2,sum(x['start_conflict'] for x in rows))
        self.assertEqual(1,len(self.store.docket('2026-11-12','102')))
        self.assertEqual([],self.store.docket('2026-11-14'))

    def test_additional_seed_does_not_duplicate(self):
        self.store.seed_workflows(); self.store.seed_workflows()
        self.assertEqual(3,len(self.store.rows('tasks')))
        self.assertEqual(1,len(self.store.rows('services')))
        self.assertEqual(2,len(self.store.rows('ledger')))
        self.assertEqual(10000,self.store.ledger_balance('DEMO-2026-1042'))

    def test_old_database_migrates_without_losing_hearings(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'old.db'
            db=sqlite3.connect(path)
            db.execute('''CREATE TABLE hearings(id INTEGER PRIMARY KEY,case_number TEXT NOT NULL,recipient TEXT NOT NULL,date TEXT NOT NULL,time TEXT NOT NULL,timezone TEXT NOT NULL,courtroom TEXT NOT NULL,previous TEXT NOT NULL DEFAULT 'Initial scheduling',revision INTEGER NOT NULL DEFAULT 1)''')
            db.execute("INSERT INTO hearings(case_number,recipient,date,time,timezone,courtroom) VALUES ('OLD-1','Original Person','2026-11-12','09:30','America/Denver','204')")
            db.commit(); db.close()
            store=Store(path)
            try:
                self.assertEqual('OLD-1',store.get('hearings',1)['case_number'])
                i=store.save_work_item('tasks',task())
                self.assertEqual('Arrange interpreter',store.get('tasks',i)['title'])
            finally: store.close()

if __name__=='__main__': unittest.main(verbosity=2)
