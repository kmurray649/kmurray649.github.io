import tempfile
import unittest
from pathlib import Path
from core import Store, validate_hearing, TEMPLATES, evaluate_filing

def hearing(**updates):
    data=dict(case_number='DEMO-1',recipient='Alex Morgan',date='2026-11-12',time='09:30',timezone='America/Denver',courtroom='204')
    return dict(data,**updates)

def filing(**updates):
    data=dict(case_number='DEMO-1',submitter='Jordan Lee',filing_type='Civil Complaint',has_complaint=True,readable=True)
    return dict(data,**updates)

class WorkflowTests(unittest.TestCase):
    def setUp(self): self.store=Store(':memory:')
    def tearDown(self): self.store.close()

    def test_notice_contains_current_details(self):
        i=self.store.save_hearing(hearing())
        doc,created=self.store.generate('hearings',i)
        self.assertTrue(created)
        for text in ['DEMO-1','Alex Morgan','2026-11-12','09:30','America/Denver','204']:
            self.assertIn(text,doc['body'])

    def test_missing_hearing_field_creates_nothing(self):
        with self.assertRaises(ValueError): self.store.save_hearing(hearing(courtroom=' '))
        self.assertEqual([],self.store.rows('hearings'))

    def test_invalid_date(self):
        with self.assertRaises(ValueError): validate_hearing(hearing(date='2026-02-30'))

    def test_invalid_zone(self):
        with self.assertRaises(ValueError): validate_hearing(hearing(timezone='Invalid/Zone'))

    def test_nonexistent_and_ambiguous_time(self):
        for date,time in [('2026-03-08','02:30'),('2026-11-01','01:30')]:
            with self.assertRaises(ValueError): validate_hearing(hearing(date=date,time=time))

    def test_retry_reuses_document(self):
        i=self.store.save_hearing(hearing())
        a,_=self.store.generate('hearings',i)
        b,created=self.store.generate('hearings',i)
        self.assertFalse(created); self.assertEqual(a['id'],b['id'])
        self.assertEqual(1,len(self.store.rows('documents')))

    def test_changed_hearing_supersedes_reviewed_draft(self):
        i=self.store.save_hearing(hearing())
        old,_=self.store.generate('hearings',i); self.store.review(old['id'])
        self.store.save_hearing(hearing(time='11:00'),i,1)
        self.assertEqual('Superseded',self.store.get('documents',old['id'])['status'])
        with self.assertRaises(ValueError): self.store.review(old['id'])
        new,_=self.store.generate('hearings',i)
        self.assertIn('11:00',new['body']); self.assertIn('09:30',new['body'])
        self.assertEqual(2,new['revision'])

    def test_unchanged_record_keeps_revision(self):
        i=self.store.save_hearing(hearing())
        self.store.save_hearing(hearing(),i,1)
        self.assertEqual(1,self.store.get('hearings',i)['revision'])

    def test_stale_edit_blocked(self):
        i=self.store.save_hearing(hearing())
        self.store.save_hearing(hearing(time='11:00'),i,1)
        with self.assertRaises(ValueError): self.store.save_hearing(hearing(time='12:00'),i,1)
        self.assertEqual('11:00',self.store.get('hearings',i)['time'])

    def test_complete_filing(self):
        queue,issues=evaluate_filing(filing())
        self.assertEqual('Civil Clerk Review',queue); self.assertEqual([],issues)

    def test_incomplete_filing(self):
        queue,issues=evaluate_filing(filing(submitter='',readable=False))
        self.assertEqual('Intake Follow-up',queue); self.assertEqual(2,len(issues))

    def test_unknown_document_type(self):
        queue,issues=evaluate_filing(filing(filing_type='Motion'))
        self.assertEqual('Manual Classification',queue); self.assertTrue(issues)

    def test_filing_retry_and_attachment_change(self):
        i=self.store.save_filing(filing(readable=False))
        old,_=self.store.generate('filings',i)
        self.store.save_filing(filing(readable=False),i,1)
        same,created=self.store.generate('filings',i)
        self.assertFalse(created); self.assertEqual(old['id'],same['id'])
        self.store.save_filing(filing(),i,1)
        new,_=self.store.generate('filings',i)
        self.assertIn('Civil Clerk Review',new['body'])
        self.assertNotIn('Items requiring review',new['body'])
        self.assertEqual('Superseded',self.store.get('documents',old['id'])['status'])

    def test_template_change_creates_new_document(self):
        i=self.store.save_hearing(hearing())
        old,_=self.store.generate('hearings',i)
        self.store.save_template('Hearing notice','CUSTOM HEADER\n'+TEMPLATES['Hearing notice'][0])
        new,_=self.store.generate('hearings',i)
        self.assertEqual(2,new['template_version']); self.assertIn('CUSTOM HEADER',new['body'])
        self.assertEqual('Superseded',self.store.get('documents',old['id'])['status'])

    def test_unknown_or_missing_template_variables_blocked(self):
        original=self.store.template('Hearing notice')['body']
        for body in ['Hello $unknown',original+'\n$unexpected',original+'\n$!']:
            with self.assertRaises(ValueError): self.store.save_template('Hearing notice',body)
        self.assertEqual(original,self.store.template('Hearing notice')['body'])

    def test_review_only_once(self):
        i=self.store.save_filing(filing())
        doc,_=self.store.generate('filings',i)
        self.store.review(doc['id'])
        self.assertEqual('Reviewed',self.store.get('documents',doc['id'])['status'])
        with self.assertRaises(ValueError): self.store.review(doc['id'])

    def test_seed_no_duplicates(self):
        self.store.seed()
        self.assertEqual(2,len(self.store.rows('hearings')))
        self.assertEqual(3,len(self.store.rows('filings')))
        with self.assertRaises(ValueError): self.store.seed()

    def test_persistence_and_cross_instance_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'workspace.db'
            a=Store(path); b=Store(path)
            try:
                i=a.save_hearing(hearing())
                doc,_=a.generate('hearings',i)
                same,created=b.generate('hearings',i)
                self.assertEqual(doc['id'],same['id']); self.assertFalse(created)
                b.save_hearing(hearing(time='13:30'),i,1)
                with self.assertRaises(ValueError): a.save_hearing(hearing(time='12:30'),i,1)
            finally: a.close(); b.close()
            c=Store(path)
            try: self.assertEqual('13:30',c.get('hearings',i)['time'])
            finally: c.close()

if __name__=='__main__': unittest.main(verbosity=2)
