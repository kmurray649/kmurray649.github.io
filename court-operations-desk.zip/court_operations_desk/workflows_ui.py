"""Desktop screens for tasks, service tracking, ledger, and daily docket."""
from datetime import date
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, simpledialog
from tkinter.scrolledtext import ScrolledText
from uuid import uuid4
from workflow_core import TASK_STATUSES, TASK_CATEGORIES, SERVICE_STATUSES, SERVICE_METHODS, task_overdue, money_text

class WorkflowUI:
    def export_text(self, text, filename, detail):
        path=filedialog.asksaveasfilename(parent=self,title='Export text',initialfile=filename,defaultextension='.txt',filetypes=[('Text document','*.txt')])
        if path:
            Path(path).write_text(text,encoding='utf-8')
            with self.store.db: self.store.log('Workflow exported',detail)
            self.status.set('Text copy exported')

    def work_items(self, table):
        self.work_table=table
        self.header('Case tasks' if table=='tasks' else 'Service tracking',
                    'Assign follow-up work, enter due dates, and track completion.' if table=='tasks' else
                    'Record service attempts and staff-reported outcomes. These entries do not establish legal service.')
        bar=ttk.Frame(self.content); bar.pack(fill='x',pady=(0,10))
        self.work_search=tk.StringVar(); self.work_status=tk.StringVar(value='All statuses'); self.only_overdue=tk.BooleanVar(value=False)
        ttk.Label(bar,text='Search').pack(side='left',padx=(0,6)); ttk.Entry(bar,textvariable=self.work_search,width=24).pack(side='left',padx=(0,12))
        statuses=TASK_STATUSES if table=='tasks' else SERVICE_STATUSES
        ttk.Combobox(bar,textvariable=self.work_status,values=('All statuses',)+statuses,state='readonly',width=19).pack(side='left',padx=(0,12))
        if table=='tasks': ttk.Checkbutton(bar,text='Overdue only',variable=self.only_overdue).pack(side='left')
        ttk.Button(bar,text='New record',command=self.new_work_item).pack(side='right')
        self.work_tree=self.tree(self.content,[('id','ID',50),('case','Case',150),('title','Task' if table=='tasks' else 'Document',210),('person','Owner' if table=='tasks' else 'Recipient',130),('date','Due date' if table=='tasks' else 'Event date',110),('status','Status',150)],height=5)
        self.work_tree.tag_configure('overdue',foreground='#b33c25')
        self.work_tree.bind('<<TreeviewSelect>>',self.select_work_item)
        for var in (self.work_search,self.work_status,self.only_overdue): var.trace_add('write',lambda *_:self.fill_work_items())
        form=ttk.LabelFrame(self.content,text='Record details',padding=12); form.pack(fill='x',pady=(15,0))
        if table=='tasks':
            fields=[('case_number','Case number',None),('title','Task title',None),('owner','Assigned to',None),('due_on','Due (YYYY-MM-DD)',None),('category','Category',TASK_CATEGORIES),('status','Status',TASK_STATUSES)]
        else:
            fields=[('case_number','Case number',None),('document_title','Document title',None),('recipient','Recipient',None),('method','Method',SERVICE_METHODS),('assigned_to','Assigned / reported by',None),('status','Status',SERVICE_STATUSES),('event_on','Event (YYYY-MM-DD)',None)]
        self.work_vars={}
        for n,(key,label,options) in enumerate(fields):
            row=n//2; col=(n%2)*2
            ttk.Label(form,text=label).grid(row=row,column=col,sticky='w',padx=(0,8),pady=4)
            var=tk.StringVar(); self.work_vars[key]=var
            widget=ttk.Combobox(form,textvariable=var,values=options,state='readonly',width=23) if options else ttk.Entry(form,textvariable=var,width=25)
            widget.grid(row=row,column=col+1,sticky='ew',padx=(0,14),pady=4); var.trace_add('write',self.dirty)
        notes_row=(len(fields)+1)//2
        ttk.Label(form,text='Notes').grid(row=notes_row,column=0,sticky='nw',pady=5)
        self.work_notes=ScrolledText(form,height=2,wrap='word',font=('Segoe UI',10),undo=True)
        self.work_notes.grid(row=notes_row,column=1,columnspan=3,sticky='ew',padx=(0,14),pady=5)
        self.work_notes.bind('<<Modified>>',self.notes_modified)
        self.work_info=tk.StringVar(value='New record')
        ttk.Label(form,textvariable=self.work_info,wraplength=750).grid(row=notes_row+1,column=0,columnspan=4,sticky='w',pady=7)
        actions=ttk.Frame(form); actions.grid(row=notes_row+2,column=0,columnspan=4,sticky='w')
        ttk.Button(actions,text='Save record',style='Accent.TButton',command=lambda:self.action(self.save_work_item)).pack(side='left',padx=(0,8))
        ttk.Button(actions,text='Export summary',command=lambda:self.action(self.export_work_item)).pack(side='left')
        form.columnconfigure(1,weight=1); form.columnconfigure(3,weight=1)
        self.fill_work_items(); self.new_work_item(force=True)

    def notes_modified(self,event=None):
        if self.work_notes.edit_modified():
            self.form_dirty=True; self.work_notes.edit_modified(False)

    def fill_work_items(self):
        self.work_tree.delete(*self.work_tree.get_children())
        for x in self.store.rows(self.work_table):
            if self.work_status.get()!='All statuses' and x['status']!=self.work_status.get(): continue
            overdue=self.work_table=='tasks' and task_overdue(x)
            if self.only_overdue.get() and not overdue: continue
            if self.work_search.get().casefold() not in ' '.join(str(v) for v in x.values()).casefold(): continue
            task=self.work_table=='tasks'
            self.work_tree.insert('','end',iid=str(x['id']),tags=('overdue',) if overdue else (),values=(x['id'],x['case_number'],x['title'] if task else x['document_title'],x['owner'] if task else x['recipient'],x['due_on'] if task else x['event_on'],x['status']+(' / Overdue' if overdue else '')))

    def new_work_item(self,force=False):
        if not force and not self.may_leave(): return
        self.selected_id=None; self.selected_revision=None
        defaults={'status':'Open' if self.work_table=='tasks' else 'Pending','category':TASK_CATEGORIES[0],'method':SERVICE_METHODS[0]}
        for k,v in self.work_vars.items(): v.set(defaults.get(k,''))
        self.work_notes.delete('1.0','end'); self.work_notes.edit_modified(False)
        if self.work_tree.selection(): self.work_tree.selection_remove(*self.work_tree.selection())
        self.work_info.set('New record | Due dates and service dates are entered by staff.')
        self.form_dirty=False

    def select_work_item(self,event=None):
        sel=self.work_tree.selection()
        if not sel or int(sel[0])==self.selected_id: return
        if not self.may_leave():
            if self.selected_id and self.work_tree.exists(str(self.selected_id)): self.work_tree.selection_set(str(self.selected_id))
            return
        self.load_work_item(int(sel[0]))

    def load_work_item(self,item_id):
        x=self.store.get(self.work_table,item_id)
        self.selected_id=item_id; self.selected_revision=x['revision']
        for k,v in self.work_vars.items(): v.set(x[k])
        self.work_notes.delete('1.0','end'); self.work_notes.insert('1.0',x['notes']); self.work_notes.edit_modified(False)
        self.work_info.set(f"Record {item_id} | Revision {x['revision']}"+(' | OVERDUE' if self.work_table=='tasks' and task_overdue(x) else ''))
        self.form_dirty=False

    def save_work_item(self):
        data={k:v.get() for k,v in self.work_vars.items()}; data['notes']=self.work_notes.get('1.0','end-1c')
        item_id=self.store.save_work_item(self.work_table,data,self.selected_id,self.selected_revision)
        self.selected_id=item_id; self.form_dirty=False
        self.fill_work_items(); self.load_work_item(item_id)
        if self.work_tree.exists(str(item_id)): self.work_tree.selection_set(str(item_id))
        self.status.set('Task saved' if self.work_table=='tasks' else 'Service record saved')

    def export_work_item(self):
        if self.selected_id is None or self.form_dirty: raise ValueError('Save this record before exporting.')
        x=self.store.get(self.work_table,self.selected_id)
        text=('CASE TASK' if self.work_table=='tasks' else 'SERVICE TRACKING RECORD')+'\n\n'
        text+='\n'.join(f'{k.replace("_"," ").title()}: {v}' for k,v in x.items())
        if self.work_table=='services': text+='\n\nStaff-reported outcome. This record does not establish legal service.'
        self.export_text(text,f'{self.work_table}_{x["id"]}.txt',f'{self.work_table}:{x["id"]}')

    def financials(self):
        self.header('Fees & payments','Record charges, payments, waivers, and reversals. This ledger does not process money or calculate court fees.')
        top=ttk.Frame(self.content); top.pack(fill='x',pady=(0,12))
        self.ledger_filter=tk.StringVar()
        ttk.Label(top,text='Case filter').pack(side='left',padx=(0,7)); ttk.Entry(top,textvariable=self.ledger_filter,width=26).pack(side='left',padx=(0,12))
        self.balance_label=ttk.Label(top,text='Enter an exact case number to view its balance.'); self.balance_label.pack(side='left')
        self.ledger_tree=self.tree(self.content,[('id','Entry',65),('case','Case',145),('kind','Type',100),('amount','Amount',95),('ref','Reference',175),('description','Description',240)],height=5)
        self.ledger_tree.bind('<<TreeviewSelect>>',self.select_ledger)
        self.ledger_filter.trace_add('write',lambda *_:self.fill_ledger())
        area=ttk.Frame(self.content); area.pack(fill='both',expand=True,pady=(14,0))
        form=ttk.LabelFrame(area,text='New ledger entry',padding=12); form.pack(side='left',fill='both',expand=True,padx=(0,12))
        self.ledger_vars={}
        fields=[('case_number','Case number'),('kind','Entry type'),('amount','Amount (USD)'),('description','Description'),('reference','Reference / receipt ID')]
        for row,(key,label) in enumerate(fields):
            ttk.Label(form,text=label).grid(row=row,column=0,sticky='w',pady=4,padx=(0,8))
            var=tk.StringVar(); self.ledger_vars[key]=var
            widget=ttk.Combobox(form,textvariable=var,values=('Charge','Payment','Waiver'),state='readonly',width=23) if key=='kind' else ttk.Entry(form,textvariable=var,width=25)
            widget.grid(row=row,column=1,sticky='ew',pady=4); var.trace_add('write',self.dirty)
        form.columnconfigure(1,weight=1)
        buttons=ttk.Frame(form); buttons.grid(row=5,column=0,columnspan=2,sticky='w',pady=10)
        ttk.Button(buttons,text='Record entry',style='Accent.TButton',command=lambda:self.action(self.post_entry)).pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Clear form',command=self.new_ledger_entry).pack(side='left')
        ttk.Label(form,text='Use the same reference to retry an entry without duplicating it.\nEntries are corrected through reversals, rather than edits.',wraplength=390).grid(row=6,column=0,columnspan=2,sticky='w',pady=7)
        right=ttk.LabelFrame(area,text='Selected entry',padding=10); right.pack(side='left',fill='both',expand=True)
        self.ledger_preview=ScrolledText(right,width=40,height=10,font=('Consolas',10),wrap='word',relief='flat'); self.ledger_preview.pack(fill='both',expand=True)
        self.set_text(self.ledger_preview,'Select an entry to inspect it or export a record.')
        actions=ttk.Frame(right); actions.pack(fill='x',pady=(8,0))
        ttk.Button(actions,text='Reverse entry',command=lambda:self.action(self.reverse_entry)).pack(side='left',padx=(0,8))
        ttk.Button(actions,text='Export record',command=lambda:self.action(self.export_entry)).pack(side='left')
        self.ledger_selected=None; self.fill_ledger(); self.new_ledger_entry(force=True)

    def fill_ledger(self):
        self.ledger_tree.delete(*self.ledger_tree.get_children())
        self.ledger_selected=None
        if hasattr(self,'ledger_preview'):
            self.set_text(self.ledger_preview,'Select an entry to inspect it or export a record.')
        case=self.ledger_filter.get().strip()
        for x in self.store.rows('ledger'):
            if case and x['case_number']!=case: continue
            self.ledger_tree.insert('','end',iid=str(x['id']),values=(f"L-{x['id']}",x['case_number'],x['kind'],money_text(x['delta_cents']),x['reference'],x['description']))
        self.balance_label.configure(text=f'Outstanding balance: {money_text(self.store.ledger_balance(case))}' if case else 'Enter an exact case number to view its balance.')

    def new_ledger_entry(self,force=False):
        if not force and not self.may_leave(): return
        defaults={'case_number':self.ledger_filter.get().strip(),'kind':'Charge','reference':'TX-'+uuid4().hex[:12]}
        for k,v in self.ledger_vars.items(): v.set(defaults.get(k,''))
        self.form_dirty=False

    def post_entry(self):
        data={k:v.get() for k,v in self.ledger_vars.items()}
        x,created=self.store.post_ledger(**data)
        self.form_dirty=False; self.ledger_filter.set(x['case_number']); self.fill_ledger()
        self.ledger_tree.selection_set(str(x['id'])); self.select_ledger()
        self.status.set('Ledger entry recorded' if created else 'Existing entry reused; no duplicate recorded')

    def ledger_text(self,item_id):
        x=self.store.get('ledger',item_id)
        reverse=next((r for r in self.store.rows('ledger') if r['reversal_of']==item_id),None)
        return (f"LOCAL LEDGER RECORD L-{item_id}\n\nCase: {x['case_number']}\nType: {x['kind']}\n"
                f"Amount: {money_text(x['amount_cents'])}\nBalance change: {money_text(x['delta_cents'])}\n"
                f"Reference: {x['reference']}\nRecorded: {x['created']}\nDescription: {x['description']}\n"
                +(f"Reverses: L-{x['reversal_of']}\n" if x['reversal_of'] else '')
                +(f"Reversed by: L-{reverse['id']}\n" if reverse else '')
                +f"\nCurrent case balance: {money_text(self.store.ledger_balance(x['case_number']))}\n"
                '\nThis entry records a staff-entered transaction. No money was processed by this application.')

    def select_ledger(self,event=None):
        sel=self.ledger_tree.selection()
        if sel:
            self.ledger_selected=int(sel[0]); self.set_text(self.ledger_preview,self.ledger_text(self.ledger_selected))

    def reverse_entry(self):
        if not self.ledger_selected: raise ValueError('Select an existing ledger entry first.')
        reason=simpledialog.askstring('Reverse ledger entry','Enter the reason for reversing this entry:',parent=self)
        if reason is None: return
        x=self.store.reverse_ledger(self.ledger_selected,reason)
        self.fill_ledger(); self.ledger_tree.selection_set(str(x['id'])); self.select_ledger()
        self.status.set('Reversal recorded; original entry retained')

    def export_entry(self):
        if not self.ledger_selected: raise ValueError('Select a ledger entry first.')
        self.export_text(self.ledger_text(self.ledger_selected),f'ledger_{self.ledger_selected}.txt',f'L-{self.ledger_selected}')

    def docket_screen(self):
        self.header('Daily docket','View hearings by date and courtroom. Dates use the saved local time zone for each hearing.')
        bar=ttk.Frame(self.content); bar.pack(fill='x',pady=(0,14))
        self.docket_day=tk.StringVar(value=date.today().isoformat()); self.docket_room=tk.StringVar()
        ttk.Label(bar,text='Date').pack(side='left',padx=(0,7)); ttk.Entry(bar,textvariable=self.docket_day,width=14).pack(side='left',padx=(0,12))
        ttk.Label(bar,text='Courtroom (optional)').pack(side='left',padx=(0,7)); ttk.Entry(bar,textvariable=self.docket_room,width=12).pack(side='left',padx=(0,12))
        ttk.Button(bar,text='Load docket',style='Accent.TButton',command=lambda:self.action(self.load_docket)).pack(side='left')
        ttk.Button(bar,text='Export .txt',command=lambda:self.action(self.export_docket)).pack(side='right')
        self.docket_info=tk.StringVar(); ttk.Label(self.content,textvariable=self.docket_info).pack(anchor='w',pady=(0,12))
        self.docket_tree=self.tree(self.content,[('time','Time',80),('zone','Time zone',160),('case','Case',150),('person','Recipient',150),('room','Room',70),('flag','Check',180)],height=12)
        self.docket_tree.tag_configure('conflict',foreground='#b33c25')
        ttk.Label(self.content,text='Warnings identify identical start times in the same courtroom. Hearing duration, judge availability, and travel time are not modeled.',wraplength=830).pack(anchor='w',pady=(14,0))
        self.load_docket()

    def load_docket(self):
        records=self.store.docket(self.docket_day.get(),self.docket_room.get())
        self.docket_tree.delete(*self.docket_tree.get_children())
        for x in records:
            self.docket_tree.insert('','end',values=(x['time'],x['timezone'],x['case_number'],x['recipient'],x['courtroom'],'Same-start overlap' if x['start_conflict'] else ''),tags=('conflict',) if x['start_conflict'] else ())
        self.docket_info.set(f"{len(records)} hearing(s) | {sum(x['start_conflict'] for x in records)} with a same-start overlap")

    def export_docket(self):
        records=self.store.docket(self.docket_day.get(),self.docket_room.get())
        self.load_docket()
        text=f'DAILY DOCKET | {self.docket_day.get()}\nCourtroom filter: {self.docket_room.get().strip() or "All"}\n\n'
        text+='\n'.join(f"{x['time']} ({x['timezone']}) | {x['case_number']} | {x['recipient']} | Room {x['courtroom']}"+(' | SAME-START OVERLAP' if x['start_conflict'] else '') for x in records) or 'No hearings match.'
        self.export_text(text,f'docket_{self.docket_day.get()}.txt','Daily docket '+self.docket_day.get())

    def load_workflow_samples(self):
        self.store.seed_workflows(); self.navigate('Overview')
        self.status.set('Sample records added to empty Tasks, Service, and Ledger modules')
