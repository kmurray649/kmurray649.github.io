# Court Operations Desk - Apache engine edition

Version 3.0. A Python desktop application with **real Apache Groovy workflow
rules** and **real Apache Velocity document templates**, running in a local
Java process. SQLite retains records, revisions, documents, and activity.

## Start

1. Extract the complete ZIP to a folder on your computer.
2. Install **Python 3.11+ with Tcl/Tk** and **Java 17+**.
3. Check Java in a new terminal:

```sh
java -version
```

4. Open the extracted folder in VS Code and run:

```sh
python app.py
```

On Windows, `py app.py` or `launch_windows.bat` also works. Reopen the
terminal after installing Java so the `java` command is available. `JAVA_HOME`
is supported when Java is absent from PATH. The bundled JARs contain Groovy
and Velocity: you do not need Maven or a separate Groovy installation.

The first launch takes a few seconds while the JVM loads scripts. Subsequent
rule evaluations and template renders reuse that process. There is no silent
Python simulation fallback if the engines or Java are unavailable.

On Windows, the Python daily-docket component may also need time-zone data:

```sh
py -m pip install tzdata
```

On Linux, install Tk support for your Python installation if needed (commonly
`python3-tk`). On macOS, use a Python distribution with Tk support. This app
runs on a desktop, rather than directly inside the ChatGPT mobile app.

## See the engines working

1. On Overview, load sample records if the workspace is empty.
2. Open **Runtime**. It reports the loaded engine versions and counts requests.
3. Open **Hearings**, select case `DEMO-2026-1042`, change the time, and save.
   `engine/rules/hearing.groovy` validates required fields, dates, zones,
   and daylight-saving edge cases.
4. Choose **Prepare draft**. Apache Velocity renders the saved notice template.
5. Open **Filing intake** and select Jordan Lee. The missing complaint routes
   to Intake Follow-up through `engine/rules/intake.groovy`.
6. In **Templates**, select Intake summary. Its real Velocity `#if` and
   `#foreach` directives choose wording and iterate over missing-item messages.
7. Prepare an intake draft, then return to Runtime. The execution counts have
   increased. Template validation also counts because it uses real renders.

Open `court_operations_desk_tutorial.pdf` for a ten-screen illustrated guide.
Use the outer right scrollbar on shorter windows to reach lower controls.

## Responsibilities

| Component | What it runs |
| --- | --- |
| Python / Tkinter | Desktop forms, navigation, selection, previews, and exports |
| Python / SQLite | Records, ledger, revisions, document storage, deduplication, and activity |
| Apache Groovy 4.0.33 | Hearing validation and filing-intake checklist/routing scripts |
| Apache Velocity 2.4.1 | Hearing notices and intake summaries, including real VTL conditions and loops |
| Local Java 17+ process | Hosts both engines and exchanges JSON lines with Python over standard input/output |

The additional task, service, ledger, and docket rules remain in Python.
The app does not claim that every workflow has been rewritten in Groovy.

## Edit rules and templates

- **Rules:** open `engine/rules/hearing.groovy` or `intake.groovy` in VS Code.
  Restart the app after changing a script. The source tabs in Runtime display
  these bundled files. Script changes produce a new engine signature.
- **Active templates:** edit them through Templates. SQLite stores each active
  template and version. Saving validates it through Apache Velocity, checks
  required/known data fields, and supersedes earlier documents of that type.
- **Default templates:** `engine/templates/*.vm` provide defaults for a new
  workspace and source examples in Runtime. Editing these files alone does
  not replace an already customized SQLite template.
- Groovy receives case data as an `input` map and returns structured results.
  The hearing script returns validity; intake returns `queue` and `issues`.
- Velocity receives context fields such as `$case_number`, `$recipient`,
  `$queue`, and `$issues`. Use `#if` and `#foreach` for document wording.

The rules are local application code, executed by Java with your user
permissions. The application executes the bundled scripts, not text entered
in the case forms. No network requests are required by the shipped workflows.

## Existing workspaces

Data is stored in `~/.court_operations_desk/workspace.sqlite3` by default.
To choose a separate practice database:

```sh
python app.py --database practice.sqlite3
```

The upgrade preserves records and existing document text. On the first switch
from the Python-only edition, previous documents become Superseded and
active template versions advance. The old default intake template is upgraded
to Velocity syntax. Custom templates are preserved and should be reviewed for
syntax differences, especially any Python-specific escaping.

Changing a Groovy script and restarting also supersedes prior documents and
re-evaluates saved filing queues. A changed routing result advances that
filing's revision. Regenerate documents from the current saved record.
Close the app before copying its database for backup.

## Workflows

Eleven sections: Overview, Hearings, Daily docket, Filing intake, Case tasks,
Service tracking, Fees & payments, Documents, Templates, Runtime, and Activity.

- **Hearings:** save schedule details, prepare notices, and track revisions.
- **Daily docket:** filter by saved local date/courtroom, flag identical starts,
  and export text. Hearing duration and judge availability are not modeled.
- **Intake:** administrative Civil Complaint checks, staff-review queues,
  missing-item summaries, and manual classification for other document types.
- **Tasks:** assignments, manually entered due dates, categories including
  interpreter/records requests, completion, and overdue filtering.
- **Service:** attempts and staff-reported outcomes, event dates, notes, export.
- **Ledger:** case balances in integer cents; recorded charges/payments/waivers;
  unique references for retries; corrections through separate reversal entries.
- **Documents:** draft review, superseded versions, template versions, export.

## Tests and verification

```sh
python -m unittest discover -v
```

All **40 tests pass**, including six dedicated Apache engine integration
checks. They verify live versions/counters, actual Velocity loops/conditions,
a Groovy source change affecting routing, engine-error recovery, migration
from older documents, and a missing-dependency error without Python fallback.
The original routing, dates, ledger, revision, and persistence tests also run
against the actual engines where applicable.

The main screens and hearing save/draft workflow have been smoke-tested in a
Linux virtual desktop. Appearance can differ on Windows/macOS; platform-specific
manual testing remains appropriate.

## Engine libraries and recovery

The `engine/lib/` folder contains pinned JARs. Their SHA-256 digests and source
URLs are in `engine/dependencies.json`; startup verifies them. If libraries
were deleted or damaged, restore them explicitly:

```sh
python setup_engine.py
```

This recovery command downloads only the listed artifacts from Maven Central
and checks their pinned digests. Normal startup works offline with the
bundled libraries and a local Java installation. License/notice files are in
`engine/licenses/` and `THIRD_PARTY_NOTICES.md`.

## Prototype boundaries

Use fictional records. This local prototype does not authenticate staff,
encrypt its database, send/serve notices, process money, inspect attachment
files, calculate statutory deadlines, or determine filing acceptance or valid
service. Activity history is not tamper-resistant. Reviewed is a local action;
exports retain the wording of the active template.

## Project files

- `app.py`, `workflows_ui.py`: interface and additional screens.
- `core.py`, `workflow_core.py`: SQLite host logic and Python administrative workflows.
- `engine_bridge.py`: managed JSON-lines JVM bridge and runtime verification.
- `engine/Runner.groovy`: actual Groovy/Velocity host.
- `engine/rules/*.groovy`: hearing and intake rules.
- `engine/templates/*.vm`: default Velocity templates.
- `engine/lib/`, `dependencies.json`, `licenses/`: runtime libraries and provenance.
- `test_core.py`, `test_workflows.py`, `test_apache_engines.py`: 40 tests.
- `setup_engine.py`, `launch_windows.bat`: recovery and launch helpers.

Technical references:
- https://docs.groovy-lang.org/docs/latest/html/documentation/guide-integrating.html
- https://velocity.apache.org/engine/2.4.1/developer-guide.html
- https://velocity.apache.org/engine/2.4.1/user-guide.html
- https://docs.python.org/3/library/tkinter.html
- https://docs.python.org/3/library/sqlite3.html
