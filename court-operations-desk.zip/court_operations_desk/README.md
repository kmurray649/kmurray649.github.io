# Court Operations Desk

A standalone Python desktop prototype for hearing records, filing intake,
case tasks, service tracking, fee/payment records, document preparation,
and clerk review. Built with Tkinter and SQLite. Version 2.1.
The interface uses normal operational navigation rather than case-study tabs.

## Start

1. Extract this ZIP to a folder on your computer.
2. Install Python 3.11 or newer with Tcl/Tk support.
3. Open a terminal in the extracted folder and run:

```sh
python app.py
```

On Windows, use `py app.py` or double-click `launch_windows.bat`.
If time-zone data is missing (common on Windows), install it once:

```sh
py -m pip install tzdata
```

On Linux, your distribution may provide Tk separately (for example,
`python3-tk` on Debian/Ubuntu). Launch using `python3 app.py`.
On macOS, use a Python installation with Tk support.
This is a desktop program; it does not run directly in the ChatGPT mobile app.

Open `court_operations_desk_tutorial.pdf` in this folder for a nine-screen
walkthrough with real screenshots, sample inputs, and expected results.
The content area scrolls vertically on shorter windows; use the scrollbar
at the far right if a control is below the visible area.

## First walkthrough

1. Choose **Load sample records** on Overview. This loads fictional hearings,
   filings, tasks, a pending service record, and two ledger entries.
2. Open **Hearings**, select a record, change the date or time, and save it.
3. Choose **Prepare draft** to preview the hearing notice.
4. Choose Prepare draft again: the existing document is reused.
5. Open **Documents** and select the draft. Mark it reviewed or export a `.txt` copy.
6. Change the hearing again. Earlier documents are labeled Superseded.
7. Open **Filing intake** and select Jordan Lee's record. Its missing attachment
   routes it to Intake Follow-up. Mark the attachment present and readable,
   save, and prepare a new summary to see Civil Clerk Review.
8. In **Templates**, edit wording while retaining all required placeholders.
   Saving creates a new template version and supersedes existing documents of that type.
9. Open **Activity** to inspect workflow events.

## Additional workflow walkthrough

| Section | What to try |
| --- | --- |
| Daily docket | Enter `2026-11-12` to see the first sample hearing. Filter by courtroom `204`. Export the list as text. |
| Case tasks | Select the overdue filing follow-up task. Assign it to another clerk or mark it Completed. Use Overdue only to check the result. Interpreter requests and records requests are available as task categories. |
| Service tracking | Select the pending hearing notice. Record an Attempted event with a past/current date, then a staff-reported outcome. A Reported served outcome requires a reporter and event date. |
| Fees & payments | Filter case `DEMO-2026-1042`. Its sample $125 charge and $25 recorded payment leave $100 outstanding. Add a payment using a new reference, retry the same reference, and confirm no duplicate. Reverse an entry with a reason to retain a visible correction history. |

Tasks and service records can be exported as text summaries. Ledger entries
can be exported as records, and all changes appear in Activity.
The Overview shows overdue tasks, service follow-up, and recorded balances.

Task due dates are manually entered; the program does not calculate statutory
deadlines. Overdue uses your computer's current calendar date, and Completed
or Cancelled tasks are excluded. The daily docket flags identical start times
in the same courtroom, accounting for saved time zones; it does not check
hearing duration or judge availability. Docket dates refer to each hearing's
saved local date. Each docket export reruns the displayed filters.

The ledger uses integer cents, blocks payments/waivers above the recorded
balance, and requires unique references. Corrections use a separate reversal
entry. Reverse related payments/waivers before reversing a charge if needed
to avoid a negative recorded balance. This is a small administrative ledger,
not trust accounting, bank reconciliation, or a payment processor.

Unsaved record and template changes prompt before being discarded.
Documents are generated from saved records, with revision checks to block stale edits.

## Capabilities and boundaries

- Ten sections: Overview, Hearings, Daily docket, Filing intake, Case tasks,
  Service tracking, Fees & payments, Documents, Templates, Activity.
- Persistent local SQLite records and activity history.
- Hearing date/time validation, including invalid and ambiguous daylight-saving times.
- Filing checklist and queue selection. Only Civil Complaint has an automated
  checklist; other document types go to Manual Classification.
- Draft deduplication by source, record, revision, and template version.
- Current draft review, superseded versions, and plain-text export.
- Custom templates with validated Python `$placeholders`.
- Assigned case tasks with due dates, categories, status, and overdue filtering.
- Service attempts and staff-reported outcomes with validation and notes.
- Case balances, recorded charges/payments/waivers, reversal history, and reference deduplication.
- Daily hearing lists with date/room filters, same-start warnings, and export.

The rules are implemented in **Python**, and rendering uses Python's
`string.Template`. This app does **not** execute Apache Groovy or Apache
Velocity. Groovy-style rules correspond to `validate_hearing` and
`evaluate_filing` in `core.py`; template rendering is in `Store.generate`.
Velocity directives such as `#if` and `#foreach` are not supported. To add
the Apache engines later, replace these boundaries with an actual JVM
integration while retaining the GUI and persistence layer.

This is a local learning/portfolio prototype with synthetic data. It does not
authenticate users, validate recipient authorization, encrypt the database,
send notices, inspect attachment files, determine legal filing acceptance,
or provide a tamper-resistant audit log. “Reviewed” records a local action;
the exported text retains draft wording. Avoid using real court records.

## Local data

By default, data is created in your home folder:
`.court_operations_desk/workspace.sqlite3`.
No sample data is loaded until you select Load sample records.
Data persists when you close and reopen the app. Existing version 1 databases
are extended automatically with the new tables; existing records are retained.
If you already loaded hearing/filing samples, **Load workflow samples** on
Overview adds synthetic records only to empty Tasks, Service, and Ledger
modules. It does not replace existing records. To use a separate workspace:

```sh
python app.py --database practice.sqlite3
```

Close the application before copying a database file for backup.
No network requests or outbound integrations are included.

## Validate the workflow rules

```sh
python -m unittest discover -v
```

The included 34 tests cover the original rules plus task dates, service events,
cent precision, partial payments, overpayment prevention, ledger retries,
reversals, docket filtering/overlaps, and migration from the original database.
All 34 pass in the build environment. They run without a graphical display.
The ten-screen navigation and hearing save/notice preparation flow have also
been smoke-tested in a Linux virtual desktop. Nine actual application captures
are included in the tutorial. Appearance may differ on Windows or macOS;
platform-specific manual QA remains.

Suggested desktop checks: visit all ten screens; save and reopen a task;
record a service attempt; add/reverse a ledger entry; export each new record
type; resize to the minimum window size; close/reopen and verify persistence.

## Files

- `app.py`: desktop interface and launch command.
- `core.py`: validation, routing, templates, SQLite persistence.
- `workflow_core.py`: tasks, service tracking, ledger rules, docket queries, migrations.
- `workflows_ui.py`: additional workflow screens.
- `test_core.py`: automated workflow tests.
- `test_workflows.py`: tests for the additional workflows and migration.
- `launch_windows.bat`: Windows launcher.

Technical references:
- https://docs.python.org/3/library/tkinter.html
- https://docs.python.org/3/library/string.html#template-strings
- https://docs.python.org/3/library/sqlite3.html
- https://docs.python.org/3/library/zoneinfo.html

Court workflow design reference: National Center for State Courts,
Court Component Model discussion in Trends in State Courts (2020), including
scheduling/calendaring, accounting/financial, workflow, and compliance functions:
https://ninthcircuit.org/sites/default/files/NCSC-Trends-In-State-Courts.pdf
These prototype workflows are illustrative, not a claim of standards compliance.
