"""Court Operations Desk - launch with python app.py (Python 3.11+)."""
import argparse
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter.scrolledtext import ScrolledText
from core import Store, TEMPLATES
from workflows_ui import WorkflowUI
from workflow_core import task_overdue, money_text
from engine_bridge import ROOT as ENGINE_ROOT

NAVY='#132c42'
TEAL='#087f8c'
BG='#eef3f7'

class App(WorkflowUI,tk.Tk):
    def __init__(self, store):
        super().__init__()
        self.store=store
        self.title('Court Operations Desk')
        self.geometry('1280x900')
        self.minsize(1180,720)
        self.configure(bg=BG)
        self.current='Overview'
        self.selected_id=None
        self.selected_revision=None
        self.preview_doc=None
        self.form_dirty=False
        self.loaded_template=''
        self.status=tk.StringVar(value=f"Ready | Groovy {store.runtime['groovy']} | Velocity {store.runtime['velocity']} | Java {store.runtime['java']}")
        style=ttk.Style(self)
        style.theme_use('clam')
        style.configure('.',font=('Segoe UI',10),background=BG,foreground=NAVY)
        style.configure('TButton',padding=(12,8))
        style.configure('Accent.TButton',background=TEAL,foreground='white')
        style.map('Accent.TButton',background=[('active','#096774')])
        style.configure('Treeview',rowheight=32,background='white',fieldbackground='white')
        style.configure('Treeview.Heading',background='#dfe8ee',font=('Segoe UI',10,'bold'),padding=7)
        style.configure('TEntry',fieldbackground='white',padding=6)
        style.configure('TCombobox',fieldbackground='white',padding=6)
        shell=tk.Frame(self,bg=BG); shell.pack(fill='both',expand=True)
        sidebar=tk.Frame(shell,bg=NAVY,width=205); sidebar.pack(side='left',fill='y'); sidebar.pack_propagate(False)
        tk.Label(sidebar,text='COURT\nOPERATIONS',bg=NAVY,fg='white',font=('Segoe UI',16,'bold'),justify='left',anchor='w').pack(anchor='w',padx=20,pady=(28,6))
        tk.Label(sidebar,text='Local workspace',bg=NAVY,fg='#a3c4d9').pack(anchor='w',padx=20,pady=(0,28))
        self.nav={}
        for name in ['Overview','Hearings','Daily docket','Filing intake','Case tasks','Service tracking','Fees & payments','Documents','Templates','Runtime','Activity']:
            btn=tk.Button(sidebar,text=name,anchor='w',bg=NAVY,fg='#d9e9f3',activebackground=TEAL,activeforeground='white',relief='flat',font=('Segoe UI',11),padx=20,pady=7,command=lambda n=name:self.navigate(n))
            btn.pack(fill='x',padx=8,pady=2); self.nav[name]=btn
        tk.Label(sidebar,text='PROTOTYPE\nSynthetic data only\nNo automated delivery',justify='left',bg=NAVY,fg='#a3c4d9',font=('Segoe UI',9)).pack(side='bottom',anchor='w',padx=20,pady=24)
        right=tk.Frame(shell,bg=BG); right.pack(side='left',fill='both',expand=True)
        ttk.Label(right,textvariable=self.status,anchor='w',padding=(24,10)).pack(side='bottom',fill='x')
        viewport=ttk.Frame(right); viewport.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(viewport,bg=BG,highlightthickness=0)
        page_scroll=ttk.Scrollbar(viewport,orient='vertical',command=self.canvas.yview)
        page_scroll.pack(side='right',fill='y'); self.canvas.pack(side='left',fill='both',expand=True)
        self.canvas.configure(yscrollcommand=page_scroll.set)
        self.content=ttk.Frame(self.canvas,padding=24)
        self.content_window=self.canvas.create_window((0,0),window=self.content,anchor='nw')
        self.content.bind('<Configure>',self.resize_content)
        self.canvas.bind('<Configure>',self.resize_content)
        self.protocol('WM_DELETE_WINDOW',self.quit_app)
        self.navigate('Overview')

    def resize_content(self,event=None):
        self.canvas.itemconfigure(self.content_window,width=max(1,self.canvas.winfo_width()),
                                  height=max(self.content.winfo_reqheight(),self.canvas.winfo_height()))
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))

    def dirty(self,*_):
        self.form_dirty=True

    def may_leave(self):
        if self.current=='Templates' and hasattr(self,'editor'):
            changed=self.editor.get('1.0','end-1c')!=self.loaded_template
        else:
            changed=self.form_dirty
        return not changed or messagebox.askyesno('Unsaved changes','Discard your unsaved changes?',parent=self)

    def navigate(self,name):
        if not self.may_leave(): return
        self.current=name; self.form_dirty=False; self.selected_id=None; self.preview_doc=None
        for child in self.content.winfo_children(): child.destroy()
        for n,b in self.nav.items(): b.configure(bg=TEAL if n==name else NAVY)
        {'Overview':self.overview,'Hearings':lambda:self.records('hearings'),
         'Filing intake':lambda:self.records('filings'),'Documents':self.documents,
         'Templates':self.templates,'Activity':self.activity,
         'Case tasks':lambda:self.work_items('tasks'),'Service tracking':lambda:self.work_items('services'),
         'Fees & payments':self.financials,'Daily docket':self.docket_screen,'Runtime':self.runtime_screen}[name]()
        self.update_idletasks(); self.resize_content(); self.canvas.yview_moveto(0)
        self.after_idle(lambda:self.canvas.yview_moveto(0))

    def header(self,title,description):
        ttk.Label(self.content,text=title,font=('Segoe UI',25,'bold')).pack(anchor='w')
        ttk.Label(self.content,text=description,wraplength=840).pack(anchor='w',pady=(5,20))

    def action(self,fn):
        try: return fn()
        except Exception as exc:
            self.status.set('Action could not be completed')
            messagebox.showerror('Check this action',str(exc),parent=self)

    def tree(self,parent,columns,height=7):
        frame=ttk.Frame(parent); frame.pack(fill='both',expand=True)
        tree=ttk.Treeview(frame,columns=[x[0] for x in columns],show='headings',height=height,selectmode='browse')
        for key,label,width in columns:
            tree.heading(key,text=label); tree.column(key,width=width,minwidth=60,stretch=True)
        scroll=ttk.Scrollbar(frame,orient='vertical',command=tree.yview)
        xscroll=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
        tree.configure(yscrollcommand=scroll.set,xscrollcommand=xscroll.set)
        tree.grid(row=0,column=0,sticky='nsew'); scroll.grid(row=0,column=1,sticky='ns'); xscroll.grid(row=1,column=0,sticky='ew')
        frame.columnconfigure(0,weight=1); frame.rowconfigure(0,weight=1)
        return tree

    def overview(self):
        self.header('A clearer view of court operations','Prepare hearing notices, route incoming filings, and review documents in one local workspace.')
        hearings=self.store.rows('hearings'); filings=self.store.rows('filings'); docs=self.store.rows('documents')
        cards=ttk.Frame(self.content); cards.pack(fill='x',pady=(0,24))
        metrics=[('Hearings',len(hearings)),('Needs follow-up',sum(x['queue']=='Intake Follow-up' for x in filings)),('Drafts to review',sum(x['status']=='Draft' for x in docs))]
        for label,value in metrics:
            card=tk.Frame(cards,bg='white',padx=22,pady=18); card.pack(side='left',fill='x',expand=True,padx=(0,12))
            tk.Label(card,text=str(value),bg='white',fg=TEAL,font=('Segoe UI',30,'bold')).pack(anchor='w')
            tk.Label(card,text=label,bg='white',fg=NAVY).pack(anchor='w')
        overdue=sum(task_overdue(x) for x in self.store.rows('tasks'))
        pending_service=sum(x['status'] in ('Pending','Attempted') for x in self.store.rows('services'))
        total_balance=sum(x['delta_cents'] for x in self.store.rows('ledger'))
        ttk.Label(self.content,text=f'Overdue tasks: {overdue}    |    Service follow-up: {pending_service}    |    Recorded outstanding balance: {money_text(total_balance)}').pack(anchor='w',pady=(0,16))
        buttons=ttk.Frame(self.content); buttons.pack(fill='x',pady=(0,20))
        ttk.Button(buttons,text='Manage hearings',style='Accent.TButton',command=lambda:self.navigate('Hearings')).pack(side='left',padx=(0,8))
        ttk.Button(buttons,text='Open filing intake',command=lambda:self.navigate('Filing intake')).pack(side='left',padx=(0,8))
        if not hearings and not filings:
            ttk.Button(buttons,text='Load sample records',command=lambda:self.action(self.load_samples)).pack(side='left')
        else:
            ttk.Button(buttons,text='Load workflow samples',command=lambda:self.action(self.load_workflow_samples)).pack(side='left')
        ttk.Label(self.content,text='Recent activity',font=('Segoe UI',14,'bold')).pack(anchor='w',pady=(0,8))
        tree=self.tree(self.content,[('created','Time',180),('action','Action',150),('detail','Detail',400)])
        for x in self.store.rows('activity')[:12]: tree.insert('', 'end',values=(x['created'],x['action'],x['detail']))
        ttk.Label(self.content,text=f"Python GUI + SQLite | Apache Groovy {self.store.runtime['groovy']} validates hearings and routes filings.\nApache Velocity {self.store.runtime['velocity']} renders notices and summaries. Open Runtime to inspect the loaded engines.",wraplength=900).pack(anchor='w',pady=(18,0))

    def load_samples(self):
        self.store.seed(); self.store.seed_workflows(); self.navigate('Overview'); self.status.set('Synthetic hearing, filing, task, service, and ledger records loaded')

    def records(self,source):
        self.source=source
        hearing=source=='hearings'
        self.header('Hearings' if hearing else 'Filing intake','Select a saved record to edit it, or create a new record below. Save changes before preparing a document.')
        bar=ttk.Frame(self.content); bar.pack(fill='x',pady=(0,10))
        self.search=tk.StringVar()
        ttk.Label(bar,text='Search').pack(side='left',padx=(0,8))
        ttk.Entry(bar,textvariable=self.search,width=35).pack(side='left')
        ttk.Button(bar,text='New record',command=self.new_record).pack(side='right')
        self.record_tree=self.tree(self.content,
            [('id','ID',55),('case','Case',170),('name','Recipient' if hearing else 'Submitter',145),('detail','Hearing / location' if hearing else 'Review queue',320),('rev','Revision',65)],height=5)
        self.record_tree.bind('<<TreeviewSelect>>',self.select_record)
        self.search.trace_add('write',lambda *_:self.fill_records())
        self.fill_records()
        area=ttk.Frame(self.content); area.pack(fill='both',expand=True,pady=(16,0))
        form=ttk.LabelFrame(area,text='Record details',padding=14); form.pack(side='left',fill='both',expand=True,padx=(0,14))
        self.vars={}
        fields=[('case_number','Case number'),('recipient','Recipient'),('date','Date (YYYY-MM-DD)'),('time','Time (24-hour HH:MM)'),('timezone','Time zone'),('courtroom','Courtroom')] if hearing else [('case_number','Case number'),('submitter','Submitter name'),('filing_type','Document type')]
        for i,(key,label) in enumerate(fields):
            ttk.Label(form,text=label).grid(row=i,column=0,sticky='w',pady=4,padx=(0,10))
            var=tk.StringVar(); self.vars[key]=var
            if key=='filing_type': widget=ttk.Combobox(form,textvariable=var,values=['Civil Complaint','Motion','Other'],state='readonly',width=25)
            else: widget=ttk.Entry(form,textvariable=var,width=26)
            widget.grid(row=i,column=1,sticky='ew',pady=4); var.trace_add('write',self.dirty)
        form.columnconfigure(1,weight=1)
        if not hearing:
            for row,(key,label) in enumerate([('has_complaint','Complaint attachment present'),('readable','Attachment marked readable')],start=3):
                var=tk.BooleanVar(); self.vars[key]=var; var.trace_add('write',self.dirty)
                ttk.Checkbutton(form,text=label,variable=var).grid(row=row,column=0,columnspan=2,sticky='w',pady=6)
            ttk.Label(form,text='Metadata only; this app does not inspect attachments.',wraplength=350).grid(row=5,column=0,columnspan=2,sticky='w',pady=8)
        self.record_info=tk.StringVar()
        ttk.Label(form,textvariable=self.record_info,wraplength=360).grid(row=7,column=0,columnspan=2,sticky='w',pady=8)
        actions=ttk.Frame(form); actions.grid(row=8,column=0,columnspan=2,sticky='w',pady=(8,0))
        ttk.Button(actions,text='Save record',style='Accent.TButton',command=lambda:self.action(self.save_record)).pack(side='left',padx=(0,7))
        ttk.Button(actions,text='Prepare draft',command=lambda:self.action(self.prepare)).pack(side='left')
        preview=ttk.LabelFrame(area,text='Document preview',padding=10); preview.pack(side='left',fill='both',expand=True)
        self.preview=ScrolledText(preview,width=42,height=12,font=('Consolas',10),wrap='word',relief='flat'); self.preview.pack(fill='both',expand=True)
        self.set_text(self.preview,'Save a record, then choose Prepare draft.\n\nDrafts remain available in Documents.')
        self.new_record(force=True)

    def fill_records(self):
        self.record_tree.delete(*self.record_tree.get_children())
        query=self.search.get().casefold()
        for x in self.store.rows(self.source):
            if query and query not in ' '.join(str(v) for v in x.values()).casefold(): continue
            hearing=self.source=='hearings'
            detail=f"{x['date']} {x['time']} / Room {x['courtroom']}" if hearing else x['queue']
            self.record_tree.insert('','end',iid=str(x['id']),values=(x['id'],x['case_number'],x['recipient'] if hearing else x['submitter'],detail,x['revision']))

    def new_record(self,force=False):
        if not force and not self.may_leave(): return
        self.selected_id=None; self.selected_revision=None
        for k,v in self.vars.items(): v.set(False if k in ('has_complaint','readable') else 'America/Denver' if k=='timezone' else 'Civil Complaint' if k=='filing_type' else '')
        if self.record_tree.selection(): self.record_tree.selection_remove(*self.record_tree.selection())
        self.record_info.set('New record'); self.form_dirty=False

    def select_record(self,event=None):
        selected=self.record_tree.selection()
        if not selected or int(selected[0])==self.selected_id: return
        if not self.may_leave():
            if self.selected_id and self.record_tree.exists(str(self.selected_id)):
                self.record_tree.selection_set(str(self.selected_id))
            return
        self.load_record(int(selected[0]))

    def load_record(self,item_id):
        x=self.store.get(self.source,item_id)
        self.selected_id=item_id; self.selected_revision=x['revision']
        for k,v in self.vars.items(): v.set(x[k])
        info=f"H-{item_id} | Revision {x['revision']}\nPrevious: {x['previous']}" if self.source=='hearings' else f"F-{item_id} | Revision {x['revision']}\n{x['queue']}\n"+'\n'.join(json.loads(x['issues']))
        self.record_info.set(info); self.form_dirty=False
        self.set_text(self.preview,'Select Prepare draft to preview the current saved record.')

    def save_record(self):
        data={k:v.get() for k,v in self.vars.items()}
        fn=self.store.save_hearing if self.source=='hearings' else self.store.save_filing
        item_id=fn(data,self.selected_id,self.selected_revision)
        self.form_dirty=False; self.selected_id=item_id
        self.fill_records(); self.load_record(item_id)
        if self.record_tree.exists(str(item_id)): self.record_tree.selection_set(str(item_id))
        self.status.set('Record saved | Workflow checks complete')

    def prepare(self):
        if self.selected_id is None or self.form_dirty:
            raise ValueError('Save this record before preparing a draft.')
        current=self.store.get(self.source,self.selected_id)
        if current['revision']!=self.selected_revision:
            raise ValueError('The record changed elsewhere. Select it again.')
        doc,created=self.store.generate(self.source,self.selected_id)
        self.preview_doc=doc['id']; self.set_text(self.preview,doc['body'])
        self.status.set(f"D-{doc['id']} | {doc['status']} | "+('Draft prepared' if created else 'Existing draft reused'))

    def set_text(self,widget,text):
        widget.configure(state='normal'); widget.delete('1.0','end'); widget.insert('1.0',text); widget.configure(state='disabled')

    def documents(self):
        self.header('Documents','Review generated drafts, retain earlier versions, and export plain-text copies.')
        self.doc_tree=self.tree(self.content,[('id','Document',85),('source','Source',110),('record','Record',65),('revision','Revision',70),('status','Status',115),('created','Created',190)],height=6)
        self.refresh_docs()
        self.doc_tree.bind('<<TreeviewSelect>>',self.select_doc)
        self.doc_preview=ScrolledText(self.content,height=14,font=('Consolas',11),wrap='word',relief='flat'); self.doc_preview.pack(fill='both',expand=True,pady=14)
        self.set_text(self.doc_preview,'Select a document to preview it.')
        bar=ttk.Frame(self.content); bar.pack(fill='x')
        ttk.Button(bar,text='Mark reviewed',style='Accent.TButton',command=lambda:self.action(self.review_doc)).pack(side='left',padx=(0,8))
        ttk.Button(bar,text='Export .txt',command=lambda:self.action(self.export_doc)).pack(side='left')
        ttk.Label(bar,text='Review does not deliver or legally serve a notice.').pack(side='right')

    def refresh_docs(self):
        self.doc_tree.delete(*self.doc_tree.get_children())
        for x in self.store.rows('documents'):
            self.doc_tree.insert('','end',iid=str(x['id']),values=(f"D-{x['id']}",x['source'],x['source_id'],x['revision'],x['status'],x['created']))

    def select_doc(self,event=None):
        sel=self.doc_tree.selection()
        if sel:
            self.preview_doc=int(sel[0]); d=self.store.get('documents',self.preview_doc)
            self.set_text(self.doc_preview,f"DOCUMENT D-{d['id']} | {d['status']} | Template v{d['template_version']}\n\n"+d['body'])

    def review_doc(self):
        if self.preview_doc is None: raise ValueError('Select a document first.')
        self.store.review(self.preview_doc)
        self.refresh_docs(); self.doc_tree.selection_set(str(self.preview_doc)); self.select_doc()
        self.status.set('Marked reviewed | No notice was sent')

    def export_doc(self):
        if self.preview_doc is None: raise ValueError('Select a document first.')
        doc=self.store.get('documents',self.preview_doc)
        name=filedialog.asksaveasfilename(parent=self,title='Export document',initialfile=f"document_{doc['id']}.txt",defaultextension='.txt',filetypes=[('Text document','*.txt')])
        if name:
            Path(name).write_text(f"Document D-{doc['id']} | Status: {doc['status']}\n\n"+doc['body'],encoding='utf-8')
            with self.store.db: self.store.log('Document exported',f"D-{doc['id']}")
            self.status.set('Document exported')

    def templates(self):
        self.header('Document templates','Apache Velocity templates: edit wording, $fields, #if conditions, and #foreach loops. Changes create a new version.')
        bar=ttk.Frame(self.content); bar.pack(fill='x',pady=(0,12))
        self.template_kind=tk.StringVar(value='Hearing notice')
        combo=ttk.Combobox(bar,textvariable=self.template_kind,values=list(TEMPLATES),state='readonly',width=26); combo.pack(side='left')
        combo.bind('<<ComboboxSelected>>',self.switch_template)
        ttk.Button(bar,text='Save template',style='Accent.TButton',command=lambda:self.action(self.save_template)).pack(side='right')
        self.placeholder_label=ttk.Label(self.content,wraplength=830); self.placeholder_label.pack(anchor='w',pady=(0,12))
        self.editor=ScrolledText(self.content,font=('Consolas',12),wrap='word',undo=True,relief='flat'); self.editor.pack(fill='both',expand=True)
        ttk.Label(self.content,text='Rendered by Apache Velocity in the local Java process. Required case fields are checked before saving.\nSaving supersedes existing documents of this type. Regenerate them from their saved records.',wraplength=900).pack(anchor='w',pady=(12,0))
        self.load_template()

    def load_template(self):
        self.active_kind=self.template_kind.get(); tpl=self.store.template(self.active_kind)
        self.loaded_template=tpl['body']; self.editor.delete('1.0','end'); self.editor.insert('1.0',tpl['body']); self.editor.edit_reset()
        self.placeholder_label.configure(text=f"Version {tpl['version']} | Required: "+', '.join('$'+x for x in sorted(TEMPLATES[self.active_kind][1])))

    def switch_template(self,event=None):
        if self.editor.get('1.0','end-1c')!=self.loaded_template and not messagebox.askyesno('Unsaved changes','Discard unsaved template changes?',parent=self):
            self.template_kind.set(self.active_kind); return
        self.load_template()

    def save_template(self):
        self.store.save_template(self.active_kind,self.editor.get('1.0','end-1c'))
        self.load_template(); self.status.set('Template saved')

    def activity(self):
        self.header('Activity history','Local event history for record changes, routing decisions, drafts, review, and export.')
        tree=self.tree(self.content,[('time','Time',190),('action','Action',160),('detail','Detail',430)],height=15)
        for x in self.store.rows('activity'): tree.insert('','end',values=(x['created'],x['action'],x['detail']))
        ttk.Label(self.content,text='This local history is editable through the database; it is not a compliance-grade audit log.',wraplength=830).pack(anchor='w',pady=(14,0))

    def runtime_screen(self):
        info=self.store.engine.about()
        self.header('Apache engine runtime','Live information returned by the local Java process. These are the actual engines used by hearing and intake workflows.')
        ttk.Label(self.content,text=f"Apache Groovy {info['groovy']}   |   Apache Velocity {info['velocity']}   |   Java {info['java']}",font=('Segoe UI',14,'bold')).pack(anchor='w',pady=(0,10))
        ttk.Label(self.content,text=f"This process: {info['rules_executed']} rule executions and {info['templates_rendered']} template renders.").pack(anchor='w',pady=(0,14))
        ttk.Label(self.content,text='Python passes JSON data to a persistent Java process. Groovy runs the hearing and intake rules; Velocity renders document text. Python retains the GUI, SQLite records, tasks, service tracking, and ledger.',wraplength=900).pack(anchor='w',pady=(0,14))
        notebook=ttk.Notebook(self.content);notebook.pack(fill='both',expand=True)
        for label,path in [('Hearing rules','rules/hearing.groovy'),('Intake rules','rules/intake.groovy'),('Hearing template','templates/hearing_notice.vm'),('Intake template','templates/intake_summary.vm')]:
            frame=ttk.Frame(notebook,padding=8);notebook.add(frame,text=label)
            text=ScrolledText(frame,width=90,height=18,font=('Consolas',10),wrap='none')
            text.pack(fill='both',expand=True);self.set_text(text,(ENGINE_ROOT/path).read_text(encoding='utf-8'))
        ttk.Label(self.content,text='These tabs show bundled source examples. Edit .groovy files in VS Code and restart to load rule changes. Use Templates to edit active document templates stored in SQLite.',wraplength=900).pack(anchor='w',pady=(14,0))

    def quit_app(self):
        if self.may_leave(): self.store.close(); self.store.engine.close(); self.destroy()

def main():
    parser=argparse.ArgumentParser(description='Court Operations Desk - local desktop prototype')
    parser.add_argument('--database',type=Path,default=Path.home()/'.court_operations_desk'/'workspace.sqlite3')
    args=parser.parse_args()
    try:
        store=Store(args.database)
    except (ValueError,OSError) as exc:
        raise SystemExit(str(exc))
    try:
        app=App(store)
    except tk.TclError as exc:
        store.close()
        raise SystemExit('A desktop display and Tk are required. Run this app on your computer.\n'+str(exc))
    app.mainloop()

if __name__=='__main__': main()
