"""Python host and SQLite storage; Groovy rules and Velocity documents."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
import re
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from workflow_core import WorkflowStore
from engine_bridge import get_engine, ROOT as ENGINE_ROOT

HEARING_TEMPLATE = '''DRAFT HEARING NOTICE - FOR CLERK REVIEW
Case: $case_number
Recipient: $recipient

Previous hearing: $previous
Updated hearing: $date at $time ($timezone)
Courtroom: $courtroom

Review appearance instructions and the approved service process.
This application does not send this notice.
'''
LEGACY_FILING_TEMPLATE = '''INTAKE SUMMARY - PENDING STAFF REVIEW
Submission: $submission_id
Case: $case_number
Submitter: $submitter
Document type: $filing_type
Assigned queue: $queue

$issues_text

Administrative review only. This does not confirm acceptance for filing.
'''
HEARING_TEMPLATE=(ENGINE_ROOT/'templates/hearing_notice.vm').read_text(encoding='utf-8')
FILING_TEMPLATE=(ENGINE_ROOT/'templates/intake_summary.vm').read_text(encoding='utf-8')
TEMPLATES = {
    'Hearing notice': (HEARING_TEMPLATE, {'case_number', 'recipient', 'previous', 'date', 'time', 'timezone', 'courtroom'}),
    'Intake summary': (FILING_TEMPLATE, {'submission_id', 'case_number', 'submitter', 'filing_type', 'queue', 'issues'}),
}

def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')

def clean(value):
    return str(value).strip()

def check_template(kind, text, engine=None):
    """Check context fields, then compile/render through Apache Velocity."""
    if len(text)>64000:raise ValueError('Template must be smaller than 64,000 characters.')
    expected=set(TEMPLATES[kind][1])
    identifiers={m.group(1) or m.group(2) for m in re.finditer(r'(?<!\\)\$!?(?:\{([A-Za-z_]\w*)[^}]*\}|([A-Za-z_]\w*))',text)}
    local=set(re.findall(r'#(?:foreach|set)\s*\(\s*\$([A-Za-z_]\w*)',text))
    allowed=expected|local|{'foreach'}
    if kind=='Intake summary':
        allowed|={'issues_text','has_issues'}
        if 'issues_text' in identifiers:expected.discard('issues')
    missing, extra=expected-identifiers,identifiers-allowed
    if missing or extra:
        pieces = []
        if missing:
            pieces.append('Required placeholders missing: ' + ', '.join(sorted(missing)))
        if extra:
            pieces.append('Unknown placeholders: ' + ', '.join(sorted(extra)))
        raise ValueError('\n'.join(pieces))
    values={key:'Example' for key in TEMPLATES[kind][1]}
    runtime=engine or get_engine()
    for issues in (['Example missing item'],[]):
        values.update(issues=issues,issues_text='\n'.join(issues),has_issues=bool(issues))
        runtime.render(text,values)

def validate_hearing(data):
    return get_engine().rule('hearing',data)

def evaluate_filing(data):
    result=get_engine().rule('intake',data)
    return result['queue'],result['issues']

class Store(WorkflowStore):
    def __init__(self, path, engine=None):
        self.engine=engine or get_engine()
        self.runtime=self.engine.about()
        if str(path) != ':memory:':
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path))
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('PRAGMA busy_timeout=5000')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS hearings (
            id INTEGER PRIMARY KEY, case_number TEXT NOT NULL,
            recipient TEXT NOT NULL, date TEXT NOT NULL, time TEXT NOT NULL,
            timezone TEXT NOT NULL, courtroom TEXT NOT NULL,
            previous TEXT NOT NULL DEFAULT 'Initial scheduling',
            revision INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS filings (
            id INTEGER PRIMARY KEY, case_number TEXT NOT NULL, submitter TEXT NOT NULL,
            filing_type TEXT NOT NULL, has_complaint INTEGER NOT NULL,
            readable INTEGER NOT NULL, queue TEXT NOT NULL,
            issues TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
            reviewed INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS templates (
            kind TEXT PRIMARY KEY, body TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY, source TEXT NOT NULL, source_id INTEGER NOT NULL,
            revision INTEGER NOT NULL, template_version INTEGER NOT NULL,
            body TEXT NOT NULL, status TEXT NOT NULL, created TEXT NOT NULL,
            UNIQUE(source, source_id, revision, template_version));
        CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY, created TEXT NOT NULL, action TEXT NOT NULL,
            detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS engine_metadata (key TEXT PRIMARY KEY,value TEXT NOT NULL);
        ''')
        with self.db:
            for kind, (text, _) in TEMPLATES.items():
                self.db.execute('INSERT OR IGNORE INTO templates(kind,body) VALUES (?,?)', (kind, text))
        self.init_workflows()
        self.migrate_engine()

    def migrate_engine(self):
        previous=self.db.execute("SELECT value FROM engine_metadata WHERE key='signature'").fetchone()
        if previous and previous['value']==self.engine.signature:return
        with self.db:
            if self.db.execute('SELECT COUNT(*) FROM documents').fetchone()[0]:
                self.db.execute("UPDATE documents SET status='Superseded'")
                self.db.execute('UPDATE templates SET version=version+1')
            # Upgrade the old default; retain custom templates and legacy issues_text data.
            if self.template('Intake summary')['body']==LEGACY_FILING_TEMPLATE:
                self.db.execute("UPDATE templates SET body=? WHERE kind='Intake summary'",(FILING_TEMPLATE,))
            for row in self.rows('filings'):
                result=self.engine.rule('intake',row)
                encoded=json.dumps(result['issues'])
                if row['queue']!=result['queue'] or row['issues']!=encoded:
                    self.db.execute('UPDATE filings SET queue=?,issues=?,revision=revision+1,reviewed=0 WHERE id=?',(result['queue'],encoded,row['id']))
            self.db.execute("INSERT OR REPLACE INTO engine_metadata(key,value) VALUES ('signature',?)",(self.engine.signature,))
            self.log('Apache engines connected',f"Groovy {self.runtime['groovy']} | Velocity {self.runtime['velocity']} | Java {self.runtime['java']}")

    def rows(self, table):
        if table not in {'hearings', 'filings', 'documents', 'activity', 'tasks', 'services', 'ledger'}:
            raise ValueError('Invalid table')
        return [dict(x) for x in self.db.execute(f'SELECT * FROM {table} ORDER BY id DESC')]

    def get(self, table, item_id):
        if table not in {'hearings', 'filings', 'documents', 'tasks', 'services', 'ledger'}:
            raise ValueError('Invalid table')
        row = self.db.execute(f'SELECT * FROM {table} WHERE id=?', (item_id,)).fetchone()
        if not row:
            raise ValueError('Record no longer exists. Refresh and try again.')
        return dict(row)

    def log(self, action, detail):
        self.db.execute('INSERT INTO activity(created,action,detail) VALUES (?,?,?)', (now(), action, detail))

    def seed(self):
        if self.db.execute('SELECT COUNT(*) FROM hearings').fetchone()[0] or self.db.execute('SELECT COUNT(*) FROM filings').fetchone()[0]:
            raise ValueError('Sample data can only be loaded into an empty workspace.')
        self.save_hearing(dict(case_number='DEMO-2026-1042', recipient='Alex Morgan', date='2026-11-12', time='09:30', timezone='America/Denver', courtroom='204'))
        self.save_hearing(dict(case_number='DEMO-2026-1078', recipient='Taylor Reed', date='2026-11-16', time='14:00', timezone='America/Denver', courtroom='102'))
        for data in [dict(case_number='DEMO-2026-1042',submitter='Jordan Lee',filing_type='Civil Complaint',has_complaint=False,readable=False),
                     dict(case_number='DEMO-2026-1078',submitter='Casey Ellis',filing_type='Civil Complaint',has_complaint=True,readable=True),
                     dict(case_number='DEMO-2026-1090',submitter='Sam Parker',filing_type='Other',has_complaint=True,readable=True)]:
            self.save_filing(data)

    def save_hearing(self, data, item_id=None, expected_revision=None):
        data = {k: clean(data.get(k, '')) for k in ['case_number','recipient','date','time','timezone','courtroom']}
        self.engine.rule('hearing',data)
        with self.db:
            if item_id is None:
                cur = self.db.execute('INSERT INTO hearings(case_number,recipient,date,time,timezone,courtroom) VALUES (:case_number,:recipient,:date,:time,:timezone,:courtroom)',data)
                item_id = cur.lastrowid
            else:
                old = self.get('hearings', item_id)
                if old['revision'] != expected_revision:
                    raise ValueError('This hearing changed elsewhere. Select it again before saving.')
                if all(old[k] == v for k,v in data.items()):
                    return item_id
                previous = f"{old['date']} at {old['time']} ({old['timezone']}), Courtroom {old['courtroom']}"
                self.db.execute('UPDATE hearings SET case_number=:case_number,recipient=:recipient,date=:date,time=:time,timezone=:timezone,courtroom=:courtroom,previous=:previous,revision=revision+1 WHERE id=:id', dict(data,previous=previous,id=item_id))
                self.db.execute("UPDATE documents SET status='Superseded' WHERE source='hearings' AND source_id=?",(item_id,))
            self.log('Hearing saved', f"H-{item_id} | {data['case_number']}")
        return item_id

    def save_filing(self, data, item_id=None, expected_revision=None):
        data = dict(data)
        for key in ['case_number', 'submitter', 'filing_type']:
            data[key] = clean(data.get(key, ''))
        if not data['case_number'] or not data['filing_type']:
            raise ValueError('Case number and document type are required.')
        data['has_complaint'] = int(bool(data.get('has_complaint')))
        data['readable'] = int(bool(data.get('readable'))) if data['has_complaint'] else 0
        result=self.engine.rule('intake',data)
        queue,issues=result['queue'],result['issues']
        data.update(queue=queue, issues=json.dumps(issues))
        with self.db:
            if item_id is None:
                cur = self.db.execute('INSERT INTO filings(case_number,submitter,filing_type,has_complaint,readable,queue,issues) VALUES (:case_number,:submitter,:filing_type,:has_complaint,:readable,:queue,:issues)',data)
                item_id = cur.lastrowid
            else:
                old = self.get('filings',item_id)
                if old['revision'] != expected_revision:
                    raise ValueError('This filing changed elsewhere. Select it again before saving.')
                keys = ['case_number','submitter','filing_type','has_complaint','readable']
                if all(old[k] == data[k] for k in keys):
                    return item_id
                self.db.execute('UPDATE filings SET case_number=:case_number,submitter=:submitter,filing_type=:filing_type,has_complaint=:has_complaint,readable=:readable,queue=:queue,issues=:issues,revision=revision+1,reviewed=0 WHERE id=:id', dict(data,id=item_id))
                self.db.execute("UPDATE documents SET status='Superseded' WHERE source='filings' AND source_id=?",(item_id,))
            self.log('Intake routed',f'F-{item_id} | {queue}')
        return item_id

    def template(self, kind):
        return dict(self.db.execute('SELECT * FROM templates WHERE kind=?',(kind,)).fetchone())

    def save_template(self, kind, text):
        check_template(kind,text,self.engine)
        with self.db:
            if self.template(kind)['body'] == text:
                return
            self.db.execute('UPDATE templates SET body=?,version=version+1 WHERE kind=?',(text,kind))
            source = 'hearings' if kind=='Hearing notice' else 'filings'
            self.db.execute("UPDATE documents SET status='Superseded' WHERE source=?",(source,))
            self.log('Template updated',kind)

    def generate(self, source, item_id):
        if source not in {'hearings','filings'}:
            raise ValueError('Unknown document source')
        # Read and create within one write transaction, also across app instances.
        self.db.execute('BEGIN IMMEDIATE')
        try:
            data = self.get(source,item_id)
            kind = 'Hearing notice' if source=='hearings' else 'Intake summary'
            tpl = self.template(kind)
            existing = self.db.execute('SELECT * FROM documents WHERE source=? AND source_id=? AND revision=? AND template_version=?',(source,item_id,data['revision'],tpl['version'])).fetchone()
            if existing:
                self.db.commit()
                return dict(existing), False
            if source=='hearings':
                self.engine.rule('hearing',data)
                values = data
            else:
                issues = json.loads(data['issues'])
                values = dict(data,submission_id=f'F-{item_id}',issues=issues,has_issues=bool(issues),
                              issues_text='Items requiring review:\n'+'\n'.join('- '+s for s in issues) if issues else 'The configured administrative checklist is complete.')
            body = self.engine.render(tpl['body'],values)
            cur = self.db.execute('INSERT INTO documents(source,source_id,revision,template_version,body,status,created) VALUES (?,?,?,?,?,?,?)',(source,item_id,data['revision'],tpl['version'],body,'Draft',now()))
            self.log('Draft prepared',f"D-{cur.lastrowid} | {data['case_number']}")
            result=self.get('documents',cur.lastrowid)
            self.db.commit()
            return result, True
        except Exception:
            self.db.rollback()
            raise

    def review(self, document_id):
        with self.db:
            cur = self.db.execute("UPDATE documents SET status='Reviewed' WHERE id=? AND status='Draft'",(document_id,))
            if cur.rowcount != 1:
                raise ValueError('Only a current draft can be marked reviewed.')
            self.log('Draft reviewed',f'D-{document_id} | Local review only; no delivery')

    def close(self):
        self.db.close()
