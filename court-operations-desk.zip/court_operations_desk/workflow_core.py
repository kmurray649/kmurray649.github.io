"""Additional administrative workflows for the local prototype."""
import json
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

TASK_STATUSES=('Open','In progress','Completed','Cancelled')
TASK_CATEGORIES=('Case follow-up','Filing follow-up','Document review','Interpreter request','Records request','Other')
SERVICE_STATUSES=('Pending','Attempted','Reported served','Returned unserved','Cancelled')
SERVICE_METHODS=('Personal service','Mail','Electronic','Other')

def iso_date(value, label, required=True):
    value=str(value).strip()
    if not value and not required:
        return ''
    try:
        result=date.fromisoformat(value)
        if result.isoformat()!=value:
            raise ValueError()
    except ValueError as exc:
        raise ValueError(f'{label}: use YYYY-MM-DD with a valid calendar date.') from exc
    return value

def amount_cents(value):
    try:
        money=Decimal(str(value).strip())
        if not money.is_finite() or money<=0 or money>Decimal('1000000'):
            raise ValueError('Enter a positive amount up to 1,000,000.00.')
        if money!=money.quantize(Decimal('0.01')):
            raise ValueError('Amounts can have at most two decimal places.')
        return int(money*100)
    except (InvalidOperation,TypeError) as exc:
        raise ValueError('Enter an amount such as 25.00, without a currency symbol.') from exc

def money_text(cents):
    return f'${Decimal(cents)/100:,.2f}'

def task_overdue(record, on=None):
    return record['status'] in ('Open','In progress') and record['due_on'] < (on or date.today()).isoformat()

class WorkflowStore:
    def init_workflows(self):
        # Additive migration: existing hearing, filing, document data is retained.
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY, case_number TEXT NOT NULL, title TEXT NOT NULL,
            owner TEXT NOT NULL, due_on TEXT NOT NULL, category TEXT NOT NULL,
            status TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY, case_number TEXT NOT NULL, document_title TEXT NOT NULL,
            recipient TEXT NOT NULL, method TEXT NOT NULL, assigned_to TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL, event_on TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
            revision INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY, case_number TEXT NOT NULL, kind TEXT NOT NULL,
            amount_cents INTEGER NOT NULL CHECK(amount_cents>0), delta_cents INTEGER NOT NULL,
            description TEXT NOT NULL, reference TEXT NOT NULL UNIQUE,
            created TEXT NOT NULL, reversal_of INTEGER UNIQUE REFERENCES ledger(id));
        CREATE INDEX IF NOT EXISTS tasks_due ON tasks(due_on,status);
        CREATE INDEX IF NOT EXISTS ledger_case ON ledger(case_number);
        ''')

    def save_work_item(self, table, values, item_id=None, expected_revision=None):
        if table=='tasks':
            keys=('case_number','title','owner','due_on','category','status','notes')
            required=('case_number','title','owner')
        elif table=='services':
            keys=('case_number','document_title','recipient','method','assigned_to','status','event_on','notes')
            required=('case_number','document_title','recipient')
        else:
            raise ValueError('Unknown workflow')
        data={key:str(values.get(key,'')).strip() for key in keys}
        missing=[k.replace('_',' ') for k in required if not data[k]]
        if missing: raise ValueError('Required: '+', '.join(missing))
        if table=='tasks':
            data['due_on']=iso_date(data['due_on'],'Due date')
            if data['status'] not in TASK_STATUSES or data['category'] not in TASK_CATEGORIES:
                raise ValueError('Choose a valid task status and category.')
        else:
            if data['status'] not in SERVICE_STATUSES or data['method'] not in SERVICE_METHODS:
                raise ValueError('Choose a valid service status and method.')
            recorded_event=data['status'] in ('Attempted','Reported served','Returned unserved')
            data['event_on']=iso_date(data['event_on'],'Event date',required=recorded_event)
            if recorded_event and data['event_on']>date.today().isoformat():
                raise ValueError('A recorded service event cannot have a future date.')
            if data['status']=='Reported served' and not data['assigned_to']:
                raise ValueError('Record who reported service before marking Reported served.')
        with self.db:
            if item_id is None:
                columns=','.join(keys)
                placeholders=','.join(':'+k for k in keys)
                cur=self.db.execute(f'INSERT INTO {table}({columns}) VALUES ({placeholders})',data)
                item_id=cur.lastrowid
            else:
                old=self.get(table,item_id)
                if old['revision']!=expected_revision:
                    raise ValueError('This record changed elsewhere. Select it again before saving.')
                if all(old[k]==data[k] for k in keys): return item_id
                assignments=','.join(k+'=:'+k for k in keys)
                cur=self.db.execute(f'UPDATE {table} SET {assignments},revision=revision+1 WHERE id=:id AND revision=:expected',dict(data,id=item_id,expected=expected_revision))
                if cur.rowcount!=1: raise ValueError('Record changed elsewhere. Reload and try again.')
            self.log('Task saved' if table=='tasks' else 'Service updated',
                     f"{table}:{item_id} | {data['case_number']} | {data['status']}")
        return item_id

    def ledger_balance(self, case_number):
        return self.db.execute('SELECT COALESCE(SUM(delta_cents),0) FROM ledger WHERE case_number=?',(case_number.strip(),)).fetchone()[0]

    def post_ledger(self, case_number, kind, amount, description, reference):
        case_number,description,reference=[str(x).strip() for x in (case_number,description,reference)]
        if not case_number or not description or not reference:
            raise ValueError('Case number, description, and reference are required.')
        if kind not in ('Charge','Payment','Waiver'): raise ValueError('Choose Charge, Payment, or Waiver.')
        cents=amount_cents(amount)
        delta=cents if kind=='Charge' else -cents
        self.db.execute('BEGIN IMMEDIATE')
        try:
            old=self.db.execute('SELECT * FROM ledger WHERE reference=?',(reference,)).fetchone()
            if old:
                if any(old[k]!=v for k,v in dict(case_number=case_number,kind=kind,amount_cents=cents,description=description).items()):
                    raise ValueError('That reference already belongs to a different ledger entry.')
                self.db.commit(); return dict(old),False
            if self.ledger_balance(case_number)+delta<0:
                raise ValueError('Payment or waiver exceeds the recorded outstanding balance.')
            created=datetime.now().astimezone().isoformat(timespec='seconds')
            cur=self.db.execute('INSERT INTO ledger(case_number,kind,amount_cents,delta_cents,description,reference,created) VALUES (?,?,?,?,?,?,?)',(case_number,kind,cents,delta,description,reference,created))
            self.log('Ledger entry recorded',f"L-{cur.lastrowid} | {case_number} | {kind} {money_text(cents)}")
            result=self.get('ledger',cur.lastrowid)
            self.db.commit(); return result,True
        except Exception:
            self.db.rollback(); raise

    def reverse_ledger(self, entry_id, reason):
        reason=str(reason).strip()
        if not reason: raise ValueError('Enter a reversal reason.')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            old=self.get('ledger',entry_id)
            if old['kind']=='Reversal': raise ValueError('A reversal cannot itself be reversed.')
            if self.db.execute('SELECT 1 FROM ledger WHERE reversal_of=?',(entry_id,)).fetchone():
                raise ValueError('This entry has already been reversed.')
            if self.ledger_balance(old['case_number'])-old['delta_cents']<0:
                raise ValueError('This reversal would create a negative balance. Reverse related payments or waivers first.')
            import uuid
            cur=self.db.execute('INSERT INTO ledger(case_number,kind,amount_cents,delta_cents,description,reference,created,reversal_of) VALUES (?,?,?,?,?,?,?,?)',
                (old['case_number'],'Reversal',old['amount_cents'],-old['delta_cents'],reason,'REV-'+uuid.uuid4().hex[:16],datetime.now().astimezone().isoformat(timespec='seconds'),entry_id))
            self.log('Ledger entry reversed',f"L-{entry_id} | Reversal L-{cur.lastrowid} | {reason}")
            result=self.get('ledger',cur.lastrowid)
            self.db.commit(); return result
        except Exception:
            self.db.rollback(); raise

    def docket(self, day, courtroom=''):
        day=iso_date(day,'Docket date')
        # A docket date refers to each hearing's saved local time zone.
        records=[x for x in self.rows('hearings') if x['date']==day and (not courtroom.strip() or x['courtroom'].casefold()==courtroom.strip().casefold())]
        groups={}
        for x in records:
            utc=datetime.fromisoformat(x['date']+'T'+x['time']).replace(tzinfo=ZoneInfo(x['timezone'])).astimezone(timezone.utc).isoformat()
            groups.setdefault((x['courtroom'].casefold(),utc),[]).append(x['id'])
        conflicts={i for ids in groups.values() if len(ids)>1 for i in ids}
        return [dict(x,start_conflict=x['id'] in conflicts) for x in sorted(records,key=lambda x:(x['time'],x['courtroom'],x['case_number']))]

    def seed_workflows(self):
        """Safe to call again: only fills empty new modules, not existing records."""
        from datetime import timedelta
        today=date.today()
        if not self.rows('tasks'):
            for title,owner,category,due in [('Review missing complaint','Clerk A','Filing follow-up',today-timedelta(days=1)),
                                             ('Arrange hearing interpreter','Clerk B','Interpreter request',today+timedelta(days=3)),
                                             ('Review records request','Clerk A','Records request',today+timedelta(days=7))]:
                self.save_work_item('tasks',dict(case_number='DEMO-2026-1042',title=title,owner=owner,category=category,due_on=due.isoformat(),status='Open',notes='Synthetic sample record.'))
        if not self.rows('services'):
            self.save_work_item('services',dict(case_number='DEMO-2026-1042',document_title='Hearing notice',recipient='Alex Morgan',method='Mail',assigned_to='Clerk B',status='Pending',event_on='',notes='Synthetic sample. Follow-up needed.'))
        if not self.rows('ledger'):
            self.post_ledger('DEMO-2026-1042','Charge','125.00','Sample administrative assessment','DEMO-CHARGE-1')
            self.post_ledger('DEMO-2026-1042','Payment','25.00','Sample payment recorded','DEMO-PAYMENT-1')
