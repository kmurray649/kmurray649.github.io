# Bundled engine libraries

The application includes unmodified published JARs fetched from Maven Central.
Pinned artifact URLs and SHA-256 digests are in `engine/dependencies.json`.

| Component | Version | License |
| --- | --- | --- |
| Apache Groovy / Groovy JSON | 4.0.33 | Apache License 2.0; bundled third-party notices also apply |
| Apache Velocity Engine Core | 2.4.1 | Apache License 2.0 |
| Apache Commons Lang | 3.17.0 | Apache License 2.0 |
| SLF4J API / NOP binding | 1.7.36 | MIT |

License and notice texts are retained in the original JARs when supplied and
copied into `engine/licenses/`. The Groovy license also covers the Groovy JSON
module. SLF4J's MIT license is in `engine/licenses/slf4j/LICENSE.txt`.

Apache, Apache Groovy, and Apache Velocity are trademarks of the Apache
Software Foundation. This personal prototype is not an Apache product and
is not affiliated with a court or justice software vendor.
