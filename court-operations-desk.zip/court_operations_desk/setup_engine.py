"""Restore the pinned Apache engine libraries if they were removed."""
from pathlib import Path
from urllib.request import urlopen
import hashlib,json

def main():
    root=Path(__file__).resolve().parent/'engine'
    deps=json.loads((root/'dependencies.json').read_text(encoding='utf-8'))
    (root/'lib').mkdir(exist_ok=True)
    for dep in deps:
        path=root/'lib'/dep['file']
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==dep['sha256']:
            print('Verified:',dep['file']);continue
        print('Downloading:',dep['file'])
        data=urlopen(dep['url'],timeout=60).read()
        if hashlib.sha256(data).hexdigest()!=dep['sha256']:
            raise SystemExit('Checksum mismatch; download was not installed: '+dep['file'])
        temp=path.with_suffix('.download')
        temp.write_bytes(data);temp.replace(path)
    print('Engine libraries ready. Install Java 17+ if needed, then run python app.py.')

if __name__=='__main__':main()
