"""JSON-lines bridge to real Apache Groovy and Apache Velocity in a local JVM."""
from __future__ import annotations
import atexit
from collections import deque
import hashlib
import json
import os
from pathlib import Path
from queue import Queue, Empty
import shutil
import subprocess
import threading

ROOT=Path(__file__).resolve().parent/'engine'

class ApacheEngine:
    def __init__(self,root=ROOT,timeout=15):
        self.root=Path(root).resolve()
        self.timeout=timeout
        self.lock=threading.RLock()
        self.process=None
        self.sequence=0
        digest=hashlib.sha256()
        for p in sorted(self.root.glob('**/*')):
            if p.is_file() and p.suffix in ('.groovy','.json'):
                digest.update(p.relative_to(self.root).as_posix().encode());digest.update(p.read_bytes())
        self.signature='apache-jvm-v1-'+digest.hexdigest()[:20]
        atexit.register(self.close)

    def start(self):
        if self.process and self.process.poll() is None:return
        manifest=self.root/'dependencies.json'
        if not manifest.exists():
            raise ValueError('Engine dependencies are missing. Run: python setup_engine.py')
        for dep in json.loads(manifest.read_text(encoding='utf-8')):
            path=self.root/'lib'/dep['file']
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=dep['sha256']:
                raise ValueError(f"Missing or damaged engine library: {dep['file']}. Run: python setup_engine.py")
        java=shutil.which('java')
        if not java and os.environ.get('JAVA_HOME'):
            candidate=Path(os.environ['JAVA_HOME'])/'bin'/('java.exe' if os.name=='nt' else 'java')
            if candidate.is_file():java=str(candidate)
        if not java:raise ValueError('Java 17+ is required. Install a Java runtime and reopen the terminal, then run python app.py.')
        self.responses=Queue()
        self.errors=deque(maxlen=20)
        command=[java,'-Xmx256m','-Dfile.encoding=UTF-8','-cp',str(self.root/'lib'/'*'),
                 'groovy.ui.GroovyMain',str(self.root/'Runner.groovy'),str(self.root)]
        self.process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
             text=True,encoding='utf-8',bufsize=1,
             creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        proc=self.process
        replies=self.responses
        errors=self.errors
        def read_stdout():
            try:
                for line in proc.stdout:
                    replies.put(line)
            finally:replies.put(None)
        def read_stderr():
            for line in proc.stderr:errors.append(line.rstrip())
        threading.Thread(target=read_stdout,daemon=True).start()
        threading.Thread(target=read_stderr,daemon=True).start()

    def request(self,operation,**values):
        with self.lock:
            starting=not self.process or self.process.poll() is not None
            self.start()
            self.sequence+=1
            payload=dict(values,id=self.sequence,operation=operation)
            try:
                self.process.stdin.write(json.dumps(payload,ensure_ascii=False)+'\n');self.process.stdin.flush()
                line=self.responses.get(timeout=max(45,self.timeout) if starting else self.timeout)
            except (BrokenPipeError,OSError,Empty) as exc:
                self.close()
                raise ValueError('The Java engine stopped or timed out. Check Java 17+ and the engine scripts.\n'+'\n'.join(self.errors)) from exc
            if line is None:
                self.close()
                raise ValueError('The Java engine could not start.\n'+'\n'.join(self.errors))
            try:
                reply=json.loads(line)
                if reply['id']!=self.sequence:raise ValueError('Unexpected engine response ID')
            except (ValueError,KeyError) as exc:
                self.close();raise ValueError('Invalid response from the Java engine.') from exc
            if not reply.get('ok'):raise ValueError(reply.get('error','Engine operation failed'))
            return reply['result']

    def about(self):return self.request('about')
    def rule(self,name,data):return self.request('rule',rule=name,input=data)
    def render(self,text,context):return self.request('render',template=text,context=context)['body']

    def close(self):
        with self.lock:
            if self.process:
                proc=self.process
                self.process=None
                try:
                    proc.stdin.close()
                    proc.wait(timeout=2)
                except (OSError,subprocess.TimeoutExpired):
                    proc.kill();proc.wait()
                for pipe in (proc.stdout,proc.stderr):
                    try:pipe.close()
                    except OSError:pass

_engine=None
_engine_lock=threading.Lock()
def get_engine():
    global _engine
    with _engine_lock:
        if _engine is None:_engine=ApacheEngine()
        return _engine
