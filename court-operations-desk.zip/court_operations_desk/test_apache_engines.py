"""Integration tests: all requests execute the bundled JVM engines."""
import shutil
import tempfile
import unittest
from pathlib import Path
from core import Store, TEMPLATES, LEGACY_FILING_TEMPLATE
from engine_bridge import ApacheEngine, get_engine, ROOT
from test_core import hearing,filing

class ApacheIntegrationTests(unittest.TestCase):
    def test_loaded_versions_and_execution_counters(self):
        engine=get_engine(); before=engine.about()
        self.assertEqual('4.0.33',before['groovy'])
        self.assertEqual('2.4.1',before['velocity'])
        self.assertGreaterEqual(int(before['java'].split('.')[0]),17)
        result=engine.rule('hearing',hearing())
        self.assertEqual('Apache Groovy',result['engine'])
        self.assertEqual('Hello Kevin',engine.render('Hello $name',{'name':'Kevin'}))
        after=engine.about()
        self.assertEqual(before['rules_executed']+1,after['rules_executed'])
        self.assertEqual(before['templates_rendered']+1,after['templates_rendered'])

    def test_velocity_conditions_and_loops_in_saved_template(self):
        store=Store(':memory:')
        try:
            text=TEMPLATES['Intake summary'][0].replace('- $issue','ISSUE: $issue')
            store.save_template('Intake summary',text)
            i=store.save_filing(filing(submitter='',readable=False))
            doc,_=store.generate('filings',i)
            self.assertEqual(2,doc['body'].count('ISSUE:'))
            self.assertNotIn('#foreach',doc['body']);self.assertNotIn('#if',doc['body'])
            store.save_filing(filing(),i,1)
            clean,_=store.generate('filings',i)
            self.assertIn('administrative checklist is complete',clean['body'])
            self.assertNotIn('ISSUE:',clean['body'])
        finally:store.close()

    def test_groovy_script_change_changes_routing(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'engine';shutil.copytree(ROOT,root)
            path=root/'rules/intake.groovy'
            path.write_text(path.read_text().replace("'Civil Clerk Review'","'Groovy Custom Queue'"))
            engine=ApacheEngine(root)
            try:
                result=engine.rule('intake',filing())
                self.assertEqual('Groovy Custom Queue',result['queue'])
                self.assertNotEqual(get_engine().signature,engine.signature)
            finally:engine.close()

    def test_velocity_error_leaves_worker_usable(self):
        engine=get_engine()
        with self.assertRaises(ValueError):engine.render('$missing',{})
        self.assertEqual('Still running',engine.render('$status',{'status':'Still running'}))

    def test_legacy_documents_superseded_and_default_template_upgraded(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'legacy.sqlite3'
            store=Store(path)
            i=store.save_filing(filing(readable=False))
            doc,_=store.generate('filings',i)
            with store.db:
                store.db.execute("UPDATE documents SET body='Legacy Python-rendered document'")
                store.db.execute("UPDATE templates SET body=? WHERE kind='Intake summary'",(LEGACY_FILING_TEMPLATE,))
                store.db.execute("DELETE FROM engine_metadata")
            store.close()
            updated=Store(path)
            try:
                self.assertEqual('Superseded',updated.get('documents',doc['id'])['status'])
                self.assertIn('#foreach',updated.template('Intake summary')['body'])
                new,created=updated.generate('filings',i)
                self.assertTrue(created);self.assertNotEqual(doc['id'],new['id'])
                self.assertIn('readable complaint attachment',new['body'])
            finally:updated.close()

    def test_missing_engine_dependencies_has_no_python_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine=ApacheEngine(Path(tmp))
            try:
                with self.assertRaisesRegex(ValueError,'setup_engine.py'):engine.about()
            finally:engine.close()

if __name__=='__main__':unittest.main(verbosity=2)
